export type StepStatus =
  | 'pending'
  | 'running'
  | 'waiting_approval'
  | 'sleeping'
  | 'completed'
  | 'failed'
  | 'retrying'
  | 'skipped'
  | 'compensated';

export type StepType = 'activity' | 'sleep' | 'human_approval' | 'parallel' | 'compensation';

export interface RetryPolicy {
  maxAttempts: number;
  initialIntervalMs: number;
  backoffCoefficient: number;
  maxIntervalMs: number;
  nonRetryableErrors?: string[];
}

export interface StepDefinition {
  id: string;
  name: string;
  type: StepType;
  description: string;
  dependsOn: string[]; // step IDs that must complete first
  taskQueue?: string;
  retryPolicy?: RetryPolicy;
  sleepDurationMs?: number; // for sleep steps
  approvalPrompt?: string; // for human_approval steps
  requiredRole?: string;
  compensationStepId?: string; // id of step to run if downstream fails
  defaultInput?: Record<string, unknown>;
  // Code snippet representing this step in TypeScript SDK
  codeSnippet?: string;
}

export interface WorkflowDefinition {
  id: string;
  name: string;
  description: string;
  version: string;
  category: 'Fintech & Compliance' | 'E-Commerce & Logistics' | 'AI & Data Pipeline' | 'DevOps & Infrastructure';
  taskQueue: string;
  steps: StepDefinition[];
  samplePayload: Record<string, unknown>;
  sdkCode: string;
}

export interface StepAttempt {
  attemptNumber: number;
  startedAt: number;
  finishedAt?: number;
  durationMs?: number;
  status: 'running' | 'completed' | 'failed';
  error?: {
    name: string;
    message: string;
    stack?: string;
    retryable: boolean;
  };
  output?: unknown;
}

export interface StepExecution {
  stepId: string;
  status: StepStatus;
  attempts: StepAttempt[];
  currentAttempt: number;
  startedAt?: number;
  finishedAt?: number;
  durationMs?: number;
  input?: unknown;
  output?: unknown;
  error?: {
    name: string;
    message: string;
    stack?: string;
    retryable: boolean;
  };
  nextRetryAt?: number;
  retryCountdownMs?: number;
  sleepUntil?: number;
  approvalData?: {
    prompt: string;
    requestedAt: number;
    expiresAt: number;
    reviewedBy?: string;
    decision?: 'approved' | 'rejected';
    decisionReason?: string;
    amendedPayload?: unknown;
  };
  logs: Array<{
    timestamp: number;
    level: 'info' | 'warn' | 'error' | 'debug';
    message: string;
  }>;
}

export type EventType =
  | 'WorkflowExecutionStarted'
  | 'ActivityTaskScheduled'
  | 'ActivityTaskStarted'
  | 'ActivityTaskHeartbeat'
  | 'ActivityTaskFailed'
  | 'RetryBackoffScheduled'
  | 'ActivityTaskCompleted'
  | 'SleepScheduled'
  | 'SleepAwakened'
  | 'HumanApprovalSuspended'
  | 'HumanApprovalResolved'
  | 'StepSkipped'
  | 'CompensationTriggered'
  | 'WorkflowExecutionCompleted'
  | 'WorkflowExecutionFailed'
  | 'WorkflowExecutionTerminated';

export interface ExecutionEvent {
  id: string;
  timestamp: number;
  type: EventType;
  stepId?: string;
  stepName?: string;
  attempt?: number;
  details: Record<string, unknown>;
  durationMs?: number;
}

export type WorkflowStatus =
  | 'running'
  | 'waiting_approval'
  | 'paused'
  | 'completed'
  | 'failed'
  | 'terminated';

export interface WorkflowRun {
  id: string;
  workflowId: string;
  workflowName: string;
  version: string;
  status: WorkflowStatus;
  startedAt: number;
  finishedAt?: number;
  durationMs?: number;
  taskQueue: string;
  trigger: 'manual' | 'api' | 'webhook' | 'cron';
  inputPayload: Record<string, unknown>;
  outputPayload?: Record<string, unknown>;
  stepExecutions: Record<string, StepExecution>;
  events: ExecutionEvent[];
  // Snapshot history for deterministic time travel replay
  snapshots?: Array<{
    eventIndex: number;
    timestamp: number;
    stepExecutions: Record<string, StepExecution>;
    status: WorkflowStatus;
  }>;
  chaosEnabled?: boolean;
  failureRate?: number; // 0 to 1
}

export interface WorkerInstance {
  id: string;
  hostname: string;
  queue: string;
  status: 'active' | 'busy' | 'draining' | 'offline';
  concurrency: number;
  activeTasks: number;
  tasksCompleted: number;
  uptimeSeconds: number;
  lastHeartbeat: number;
}

export interface TaskQueueInfo {
  name: string;
  type: 'fifo' | 'standard';
  activeWorkers: number;
  pendingTasks: number;
  completedTasksLastHour: number;
  p95LatencyMs: number;
}
