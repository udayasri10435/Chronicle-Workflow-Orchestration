import {
  WorkflowDefinition,
  WorkflowRun,
  StepExecution,
  ExecutionEvent,
  EventType,
  StepStatus,
  WorkerInstance,
  TaskQueueInfo,
} from '../types/workflow';
import { PRESET_WORKFLOWS } from './presets';

// Default worker instances
export const INITIAL_WORKERS: WorkerInstance[] = [
  {
    id: 'worker-us-east-01',
    hostname: 'i-0482910fa-east1',
    queue: 'compliance-queue',
    status: 'active',
    concurrency: 16,
    activeTasks: 3,
    tasksCompleted: 1420,
    uptimeSeconds: 84210,
    lastHeartbeat: Date.now(),
  },
  {
    id: 'worker-us-east-02',
    hostname: 'i-0482910fa-east2',
    queue: 'payments-queue',
    status: 'active',
    concurrency: 24,
    activeTasks: 5,
    tasksCompleted: 4892,
    uptimeSeconds: 120400,
    lastHeartbeat: Date.now(),
  },
  {
    id: 'worker-eu-west-01',
    hostname: 'i-091244ac-eu1',
    queue: 'warehouse-queue',
    status: 'active',
    concurrency: 8,
    activeTasks: 1,
    tasksCompleted: 890,
    uptimeSeconds: 41200,
    lastHeartbeat: Date.now(),
  },
  {
    id: 'worker-ai-gpu-01',
    hostname: 'g4dn-worker-01',
    queue: 'ai-data-engine',
    status: 'busy',
    concurrency: 4,
    activeTasks: 4,
    tasksCompleted: 310,
    uptimeSeconds: 19400,
    lastHeartbeat: Date.now(),
  },
  {
    id: 'worker-devops-01',
    hostname: 'runner-canary-08',
    queue: 'devops-runners',
    status: 'active',
    concurrency: 12,
    activeTasks: 2,
    tasksCompleted: 1140,
    uptimeSeconds: 98100,
    lastHeartbeat: Date.now(),
  },
];

export const INITIAL_QUEUES: TaskQueueInfo[] = [
  {
    name: 'compliance-queue',
    type: 'standard',
    activeWorkers: 4,
    pendingTasks: 2,
    completedTasksLastHour: 240,
    p95LatencyMs: 340,
  },
  {
    name: 'payments-queue',
    type: 'fifo',
    activeWorkers: 6,
    pendingTasks: 5,
    completedTasksLastHour: 1820,
    p95LatencyMs: 145,
  },
  {
    name: 'warehouse-queue',
    type: 'standard',
    activeWorkers: 3,
    pendingTasks: 1,
    completedTasksLastHour: 320,
    p95LatencyMs: 280,
  },
  {
    name: 'ai-data-engine',
    type: 'standard',
    activeWorkers: 2,
    pendingTasks: 8,
    completedTasksLastHour: 95,
    p95LatencyMs: 1240,
  },
  {
    name: 'devops-runners',
    type: 'standard',
    activeWorkers: 3,
    pendingTasks: 0,
    completedTasksLastHour: 75,
    p95LatencyMs: 410,
  },
];

// Helper to generate IDs
export const createId = (prefix: string) =>
  `${prefix}_${Math.random().toString(36).substring(2, 9)}${Date.now().toString(36).substring(4)}`;

export class WorkflowOrchestrator {
  private runs: Map<string, WorkflowRun> = new Map();
  private timers: Map<string, NodeJS.Timeout> = new Map();
  private listeners: Set<(runs: WorkflowRun[]) => void> = new Set();
  private chaosMode = false;
  private failureRate = 0.35; // 35% chance to fail retryable activity when chaos is enabled

  constructor() {
    this.loadState();
    if (this.runs.size === 0) {
      this.seedInitialRuns();
    }
  }

  public subscribe(listener: (runs: WorkflowRun[]) => void): () => void {
    this.listeners.add(listener);
    listener(this.getAllRuns());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const all = this.getAllRuns();
    this.saveState();
    this.listeners.forEach((listener) => listener(all));
  }

  public getAllRuns(): WorkflowRun[] {
    return Array.from(this.runs.values()).sort((a, b) => b.startedAt - a.startedAt);
  }

  public getRun(id: string): WorkflowRun | undefined {
    return this.runs.get(id);
  }

  public setChaosMode(enabled: boolean, rate?: number) {
    this.chaosMode = enabled;
    if (rate !== undefined) this.failureRate = rate;
  }

  public getChaosSettings() {
    return { enabled: this.chaosMode, rate: this.failureRate };
  }

  // Create and launch a new workflow run
  public triggerWorkflow(
    workflowId: string,
    customPayload?: Record<string, unknown>,
    trigger: 'manual' | 'api' | 'webhook' | 'cron' = 'manual'
  ): WorkflowRun {
    const def = PRESET_WORKFLOWS.find((w) => w.id === workflowId);
    if (!def) throw new Error(`Workflow definition ${workflowId} not found`);

    const payload = customPayload || def.samplePayload;
    const runId = createId('run');
    const now = Date.now();

    const initialStepExecutions: Record<string, StepExecution> = {};
    def.steps.forEach((step) => {
      initialStepExecutions[step.id] = {
        stepId: step.id,
        status: 'pending',
        attempts: [],
        currentAttempt: 0,
        logs: [],
      };
    });

    const initialEvent: ExecutionEvent = {
      id: createId('evt'),
      timestamp: now,
      type: 'WorkflowExecutionStarted',
      details: {
        workflowId: def.id,
        workflowName: def.name,
        version: def.version,
        taskQueue: def.taskQueue,
        trigger,
        payload,
      },
    };

    const newRun: WorkflowRun = {
      id: runId,
      workflowId: def.id,
      workflowName: def.name,
      version: def.version,
      status: 'running',
      startedAt: now,
      taskQueue: def.taskQueue,
      trigger,
      inputPayload: payload,
      stepExecutions: initialStepExecutions,
      events: [initialEvent],
      snapshots: [
        {
          eventIndex: 0,
          timestamp: now,
          stepExecutions: JSON.parse(JSON.stringify(initialStepExecutions)),
          status: 'running',
        },
      ],
      chaosEnabled: this.chaosMode,
      failureRate: this.failureRate,
    };

    this.runs.set(runId, newRun);
    this.notify();

    // Advance the execution state machine
    this.tick(runId);
    return newRun;
  }

  // Core execution tick: checks which steps can be transitioned
  private tick(runId: string) {
    const run = this.runs.get(runId);
    if (!run || run.status === 'paused' || run.status === 'completed' || run.status === 'failed' || run.status === 'terminated') {
      return;
    }

    const def = PRESET_WORKFLOWS.find((w) => w.id === run.workflowId);
    if (!def) return;

    let allCompleted = true;
    let anyFailed = false;
    let anyWaitingApproval = false;

    for (const step of def.steps) {
      if (step.type === 'compensation') {
        // Skip compensation in normal forward execution
        continue;
      }

      const exec = run.stepExecutions[step.id];
      if (!exec) continue;

      if (exec.status === 'failed') {
        anyFailed = true;
      }
      if (exec.status === 'waiting_approval') {
        anyWaitingApproval = true;
      }
      if (exec.status !== 'completed' && exec.status !== 'skipped') {
        allCompleted = false;
      }

      // Check if step is pending and all dependencies are completed
      if (exec.status === 'pending') {
        const depsSatisfied = step.dependsOn.every(
          (depId) => run.stepExecutions[depId]?.status === 'completed' || run.stepExecutions[depId]?.status === 'skipped'
        );

        if (depsSatisfied) {
          this.executeStep(runId, step);
        }
      }
    }

    if (anyWaitingApproval) {
      run.status = 'waiting_approval';
      this.notify();
      return;
    }

    if (anyFailed) {
      // Check if compensation is configured
      const compensationStep = def.steps.find((s) => s.type === 'compensation');
      if (compensationStep && run.stepExecutions[compensationStep.id]?.status === 'pending') {
        this.executeCompensation(runId, compensationStep);
      } else {
        run.status = 'failed';
        run.finishedAt = Date.now();
        run.durationMs = run.finishedAt - run.startedAt;
        this.addEvent(run, 'WorkflowExecutionFailed', {
          error: 'One or more non-retryable steps failed or exhausted maximum retry attempts.',
        });
        this.notify();
      }
      return;
    }

    if (allCompleted) {
      run.status = 'completed';
      run.finishedAt = Date.now();
      run.durationMs = run.finishedAt - run.startedAt;
      run.outputPayload = {
        status: 'SUCCESS',
        workflowId: run.workflowId,
        completedAt: new Date(run.finishedAt).toISOString(),
        totalSteps: def.steps.filter((s) => s.type !== 'compensation').length,
        durationMs: run.durationMs,
      };
      this.addEvent(run, 'WorkflowExecutionCompleted', {
        durationMs: run.durationMs,
        output: run.outputPayload,
      });
      this.notify();
    }
  }

  private executeStep(runId: string, step: WorkflowDefinition['steps'][number]) {
    const run = this.runs.get(runId);
    if (!run || run.status === 'paused' || run.status === 'terminated') return;

    const exec = run.stepExecutions[step.id];
    if (!exec || exec.status === 'running' || exec.status === 'completed' || exec.status === 'retrying') return;

    if (step.type === 'sleep') {
      this.handleSleepStep(run, step);
      return;
    }

    if (step.type === 'human_approval') {
      this.handleApprovalStep(run, step);
      return;
    }

    // Activity Step
    this.handleActivityStep(run, step);
  }

  private handleSleepStep(run: WorkflowRun, step: WorkflowDefinition['steps'][number]) {
    const exec = run.stepExecutions[step.id];
    const duration = step.sleepDurationMs || 4000;
    const now = Date.now();

    exec.status = 'sleeping';
    exec.startedAt = now;
    exec.sleepUntil = now + duration;
    exec.logs.push({
      timestamp: now,
      level: 'info',
      message: `Workflow suspended for durable timer: ${duration}ms (${duration / 1000}s)`,
    });

    this.addEvent(run, 'SleepScheduled', {
      stepId: step.id,
      stepName: step.name,
      durationMs: duration,
      wakeAt: exec.sleepUntil,
    });
    this.notify();

    const timer = setTimeout(() => {
      const currentRun = this.runs.get(run.id);
      if (!currentRun || currentRun.status === 'terminated') return;
      const currentExec = currentRun.stepExecutions[step.id];
      if (currentExec && currentExec.status === 'sleeping') {
        currentExec.status = 'completed';
        currentExec.finishedAt = Date.now();
        currentExec.durationMs = currentExec.finishedAt - (currentExec.startedAt || now);
        currentExec.output = { timerAwakened: true, durationElapsedMs: currentExec.durationMs };
        currentExec.logs.push({
          timestamp: Date.now(),
          level: 'info',
          message: `Durable timer awakened. Resuming workflow DAG execution.`,
        });

        this.addEvent(currentRun, 'SleepAwakened', {
          stepId: step.id,
          stepName: step.name,
          durationMs: currentExec.durationMs,
        });
        this.notify();
        this.tick(run.id);
      }
    }, duration);

    this.timers.set(`${run.id}_${step.id}`, timer);
  }

  private handleApprovalStep(run: WorkflowRun, step: WorkflowDefinition['steps'][number]) {
    const exec = run.stepExecutions[step.id];
    const now = Date.now();

    exec.status = 'waiting_approval';
    exec.startedAt = now;
    exec.approvalData = {
      prompt: step.approvalPrompt || 'Human confirmation required before proceeding.',
      requestedAt: now,
      expiresAt: now + 86400000, // 24 hours
    };
    exec.input = run.inputPayload;
    exec.logs.push({
      timestamp: now,
      level: 'warn',
      message: `Workflow suspended: awaiting human review and cryptographic signoff.`,
    });

    run.status = 'waiting_approval';
    this.addEvent(run, 'HumanApprovalSuspended', {
      stepId: step.id,
      stepName: step.name,
      prompt: exec.approvalData.prompt,
      requiredRole: step.requiredRole,
      payload: run.inputPayload,
    });
    this.notify();
  }

  private handleActivityStep(run: WorkflowRun, step: WorkflowDefinition['steps'][number]) {
    const exec = run.stepExecutions[step.id];
    const now = Date.now();
    const attemptNum = exec.currentAttempt + 1;
    exec.currentAttempt = attemptNum;
    exec.status = 'running';
    if (!exec.startedAt) exec.startedAt = now;

    // Build input from parent steps or payload
    const parentOutputs: Record<string, unknown> = {};
    step.dependsOn.forEach((depId) => {
      parentOutputs[depId] = run.stepExecutions[depId]?.output;
    });
    exec.input = {
      workflowInput: run.inputPayload,
      parentOutputs,
    };

    const attemptRecord = {
      attemptNumber: attemptNum,
      startedAt: now,
      status: 'running' as const,
    };
    exec.attempts.push(attemptRecord);

    exec.logs.push({
      timestamp: now,
      level: 'info',
      message: `Dispatched activity to queue [${step.taskQueue || run.taskQueue}]. Attempt #${attemptNum}`,
    });

    this.addEvent(run, 'ActivityTaskStarted', {
      stepId: step.id,
      stepName: step.name,
      attempt: attemptNum,
      queue: step.taskQueue || run.taskQueue,
    });
    this.notify();

    // Determine execution latency (simulated work between 800ms and 2200ms)
    const executionDuration = Math.floor(Math.random() * 1200) + 900;

    const timer = setTimeout(() => {
      const currentRun = this.runs.get(run.id);
      if (!currentRun || currentRun.status === 'terminated' || currentRun.status === 'paused') return;

      const currentExec = currentRun.stepExecutions[step.id];
      if (!currentExec || currentExec.status !== 'running') return;

      const currentAttempt = currentExec.attempts[currentExec.attempts.length - 1];
      const finishTime = Date.now();

      // Determine if step should fail (chaos mode or flakiness)
      const isFlakyStep = step.id.includes('payment') || step.id.includes('vector') || step.id.includes('sanctions');
      const shouldFail = (this.chaosMode && Math.random() < this.failureRate) || (isFlakyStep && attemptNum === 1);

      if (shouldFail) {
        // Step failed!
        const maxAttempts = step.retryPolicy?.maxAttempts || 3;
        const isExhausted = attemptNum >= maxAttempts;

        const errorTypes = [
          { name: 'GatewayRateLimitError', message: 'HTTP 429: Too Many Requests. Upstream quota exhausted.' },
          { name: 'SocketTimeoutError', message: 'Connection reset by peer after 5000ms idle keep-alive.' },
          { name: 'TransientServiceUnavailableError', message: 'HTTP 503: Upstream replica failover in progress.' },
        ];
        const error = errorTypes[Math.floor(Math.random() * errorTypes.length)];

        currentAttempt.status = 'failed';
        currentAttempt.finishedAt = finishTime;
        currentAttempt.durationMs = finishTime - currentAttempt.startedAt;
        currentAttempt.error = {
          name: error.name,
          message: error.message,
          retryable: !isExhausted,
          stack: `${error.name}: ${error.message}\n    at HttpClient.executeActivity (/node_modules/@chronicle/worker/runtime.js:84:12)\n    at Object.runActivity (/src/workflows/${run.workflowId}.ts:42:19)`,
        };

        currentExec.error = currentAttempt.error;
        currentExec.logs.push({
          timestamp: finishTime,
          level: 'error',
          message: `Activity execution failed: ${error.name} - ${error.message}`,
        });

        this.addEvent(currentRun, 'ActivityTaskFailed', {
          stepId: step.id,
          stepName: step.name,
          attempt: attemptNum,
          error: error.message,
        });

        if (isExhausted) {
          // Max attempts reached: terminal step failure
          currentExec.status = 'failed';
          currentExec.finishedAt = finishTime;
          currentExec.durationMs = finishTime - (currentExec.startedAt || finishTime);
          currentExec.logs.push({
            timestamp: finishTime,
            level: 'error',
            message: `Max retry attempts (${maxAttempts}) exhausted. Escalating terminal failure to orchestrator.`,
          });
          this.notify();
          this.tick(run.id);
        } else {
          // Schedule exponential backoff retry!
          currentExec.status = 'retrying';
          const retryPolicy = step.retryPolicy || {
            maxAttempts: 3,
            initialIntervalMs: 1500,
            backoffCoefficient: 2.0,
            maxIntervalMs: 20000,
          };
          const backoffDelay = Math.min(
            retryPolicy.initialIntervalMs * Math.pow(retryPolicy.backoffCoefficient, attemptNum - 1),
            retryPolicy.maxIntervalMs
          );

          currentExec.nextRetryAt = finishTime + backoffDelay;
          currentExec.retryCountdownMs = backoffDelay;

          currentExec.logs.push({
            timestamp: finishTime,
            level: 'warn',
            message: `Retry scheduled with exponential backoff: attempt #${attemptNum + 1} in ${(backoffDelay / 1000).toFixed(1)}s`,
          });

          this.addEvent(currentRun, 'RetryBackoffScheduled', {
            stepId: step.id,
            stepName: step.name,
            nextAttempt: attemptNum + 1,
            delayMs: backoffDelay,
          });
          this.notify();

          // Schedule next attempt
          const retryTimer = setTimeout(() => {
            const r = this.runs.get(run.id);
            if (!r || r.status === 'terminated') return;
            const e = r.stepExecutions[step.id];
            if (e && e.status === 'retrying') {
              e.nextRetryAt = undefined;
              e.retryCountdownMs = undefined;
              this.handleActivityStep(r, step);
            }
          }, backoffDelay);

          this.timers.set(`${run.id}_${step.id}_retry`, retryTimer);
        }
      } else {
        // Step Succeeded!
        currentAttempt.status = 'completed';
        currentAttempt.finishedAt = finishTime;
        currentAttempt.durationMs = finishTime - currentAttempt.startedAt;
        currentAttempt.output = this.generateStepOutput(step.id, run);

        currentExec.status = 'completed';
        currentExec.finishedAt = finishTime;
        currentExec.durationMs = finishTime - (currentExec.startedAt || finishTime);
        currentExec.output = currentAttempt.output;
        currentExec.error = undefined;
        currentExec.logs.push({
          timestamp: finishTime,
          level: 'info',
          message: `Activity successfully completed in ${currentAttempt.durationMs}ms (Attempt #${attemptNum})`,
        });

        this.addEvent(currentRun, 'ActivityTaskCompleted', {
          stepId: step.id,
          stepName: step.name,
          attempt: attemptNum,
          durationMs: currentAttempt.durationMs,
        });
        this.notify();
        this.tick(run.id);
      }
    }, executionDuration);

    this.timers.set(`${run.id}_${step.id}`, timer);
  }

  private executeCompensation(runId: string, compensationStep: WorkflowDefinition['steps'][number]) {
    const run = this.runs.get(runId);
    if (!run) return;

    const exec = run.stepExecutions[compensationStep.id];
    if (!exec) return;

    const now = Date.now();
    exec.status = 'running';
    exec.startedAt = now;
    exec.logs.push({
      timestamp: now,
      level: 'warn',
      message: `Executing Saga compensation rollback: [${compensationStep.name}]`,
    });

    this.addEvent(run, 'CompensationTriggered', {
      stepId: compensationStep.id,
      stepName: compensationStep.name,
    });
    this.notify();

    setTimeout(() => {
      const currentRun = this.runs.get(runId);
      if (!currentRun) return;
      const currentExec = currentRun.stepExecutions[compensationStep.id];
      if (currentExec) {
        currentExec.status = 'compensated';
        currentExec.finishedAt = Date.now();
        currentExec.durationMs = currentExec.finishedAt - now;
        currentExec.output = { compensationRollback: 'SUCCESS', rollbackAt: new Date().toISOString() };
        currentExec.logs.push({
          timestamp: Date.now(),
          level: 'info',
          message: `Saga compensation finished. State safely neutralized.`,
        });

        currentRun.status = 'failed';
        currentRun.finishedAt = Date.now();
        currentRun.durationMs = currentRun.finishedAt - currentRun.startedAt;
        this.addEvent(currentRun, 'WorkflowExecutionFailed', {
          error: 'Workflow halted due to error; saga rollback executed successfully.',
        });
        this.notify();
      }
    }, 1200);
  }

  // Human in the loop action: approve or reject
  public resolveApproval(
    runId: string,
    stepId: string,
    decision: 'approved' | 'rejected',
    reason?: string,
    amendedPayload?: Record<string, unknown>
  ) {
    const run = this.runs.get(runId);
    if (!run) return;

    const exec = run.stepExecutions[stepId];
    if (!exec || exec.status !== 'waiting_approval') return;

    const now = Date.now();
    if (exec.approvalData) {
      exec.approvalData.decision = decision;
      exec.approvalData.decisionReason = reason;
      exec.approvalData.reviewedBy = 'sec_officer_m_chen@org.internal';
      exec.approvalData.amendedPayload = amendedPayload;
    }

    if (decision === 'approved') {
      exec.status = 'completed';
      exec.finishedAt = now;
      exec.durationMs = now - (exec.startedAt || now);
      exec.output = {
        approved: true,
        decisionTimestamp: now,
        reviewedBy: 'sec_officer_m_chen@org.internal',
        reason: reason || 'Manual review passed: compliance invariants met.',
        amendedPayload: amendedPayload || null,
      };
      if (amendedPayload) {
        run.inputPayload = { ...run.inputPayload, ...amendedPayload };
      }
      exec.logs.push({
        timestamp: now,
        level: 'info',
        message: `Human approval GRANTED by sec_officer_m_chen@org.internal. Resuming execution.`,
      });

      this.addEvent(run, 'HumanApprovalResolved', {
        stepId,
        decision: 'approved',
        reason,
        reviewedBy: 'sec_officer_m_chen@org.internal',
      });

      run.status = 'running';
      this.notify();
      this.tick(run.id);
    } else {
      exec.status = 'failed';
      exec.finishedAt = now;
      exec.durationMs = now - (exec.startedAt || now);
      exec.error = {
        name: 'HumanReviewRejectionError',
        message: reason || 'Compliance officer rejected onboarding criteria.',
        retryable: false,
      };
      exec.logs.push({
        timestamp: now,
        level: 'error',
        message: `Human approval REJECTED: ${reason || 'Denied by reviewer'}. Halting workflow.`,
      });

      this.addEvent(run, 'HumanApprovalResolved', {
        stepId,
        decision: 'rejected',
        reason,
        reviewedBy: 'sec_officer_m_chen@org.internal',
      });

      run.status = 'failed';
      run.finishedAt = now;
      run.durationMs = now - run.startedAt;
      this.notify();
      this.tick(run.id);
    }
  }

  // Developer action: manual retry step right now
  public retryStepNow(runId: string, stepId: string) {
    const run = this.runs.get(runId);
    if (!run) return;
    const def = PRESET_WORKFLOWS.find((w) => w.id === run.workflowId);
    const step = def?.steps.find((s) => s.id === stepId);
    if (!step) return;

    // Clear any pending timeout
    const existingTimer = this.timers.get(`${runId}_${stepId}_retry`);
    if (existingTimer) clearTimeout(existingTimer);

    const exec = run.stepExecutions[stepId];
    if (exec) {
      exec.nextRetryAt = undefined;
      exec.retryCountdownMs = undefined;
      if (run.status === 'failed') {
        run.status = 'running';
        run.finishedAt = undefined;
      }
      this.handleActivityStep(run, step);
    }
  }

  // Developer action: skip step with mock output
  public skipStep(runId: string, stepId: string, mockOutput?: Record<string, unknown>) {
    const run = this.runs.get(runId);
    if (!run) return;
    const exec = run.stepExecutions[stepId];
    if (!exec) return;

    const now = Date.now();
    exec.status = 'skipped';
    exec.finishedAt = now;
    exec.output = mockOutput || { skippedByDeveloper: true, mockReason: 'Developer manual override' };
    exec.logs.push({
      timestamp: now,
      level: 'warn',
      message: `Step manually SKIPPED by developer operator. Injected mock output.`,
    });

    this.addEvent(run, 'StepSkipped', {
      stepId,
      mockOutput: exec.output,
    });

    if (run.status === 'failed' || run.status === 'waiting_approval') {
      run.status = 'running';
    }
    this.notify();
    this.tick(run.id);
  }

  // Terminate run
  public terminateRun(runId: string, reason = 'Operator invoked terminate command') {
    const run = this.runs.get(runId);
    if (!run) return;

    const now = Date.now();
    run.status = 'terminated';
    run.finishedAt = now;
    run.durationMs = now - run.startedAt;

    this.addEvent(run, 'WorkflowExecutionTerminated', { reason });
    this.notify();
  }

  // Pause / Resume run
  public togglePause(runId: string) {
    const run = this.runs.get(runId);
    if (!run) return;

    if (run.status === 'paused') {
      run.status = 'running';
      this.notify();
      this.tick(run.id);
    } else if (run.status === 'running') {
      run.status = 'paused';
      this.notify();
    }
  }

  // Add event and record replay snapshot
  private addEvent(run: WorkflowRun, type: EventType, details: Record<string, unknown>) {
    const event: ExecutionEvent = {
      id: createId('evt'),
      timestamp: Date.now(),
      type,
      details,
    };
    run.events.push(event);

    if (!run.snapshots) run.snapshots = [];
    run.snapshots.push({
      eventIndex: run.events.length - 1,
      timestamp: event.timestamp,
      stepExecutions: JSON.parse(JSON.stringify(run.stepExecutions)),
      status: run.status,
    });
  }

  private generateStepOutput(stepId: string, run: WorkflowRun): Record<string, unknown> {
    switch (stepId) {
      case 'verify-identity':
        return {
          entityId: 'ent_delaware_94821',
          taxIdVerified: true,
          incorporationStatus: 'ACTIVE_GOOD_STANDING',
          sanctionsWatchlistHit: false,
          confidenceScore: 0.99,
        };
      case 'screen-ofac-sanctions':
        return {
          screenedLists: ['OFAC-SDN', 'UN-CONSOLIDATED', 'EU-FSF', 'INTERPOL-RED'],
          flaggedMatches: 0,
          flags: [],
          clearedAt: new Date().toISOString(),
        };
      case 'evaluate-credit-risk':
        return {
          dunsScore: 78,
          creditRating: 'AA-',
          recommendedMaxCreditUsd: 500000,
          projectedDefaultProbability: 0.008,
        };
      case 'provision-tenant-workspace':
        return {
          id: 'ws_prod_09912a',
          clusterUrl: 'https://elysian-corp.us-east.chronicle.cloud',
          vpcPeeringActive: true,
          kmsKeyArn: 'arn:aws:kms:us-east-1:49210:key/8a2f-110c',
        };
      case 'dispatch-welcome-credentials':
        return {
          emailSent: true,
          recipient: (run.inputPayload.contactEmail as string) || 'treasury@elysian.internal',
          ssoPortalProvisioned: true,
          temporaryTokenExpiry: '72h',
        };
      case 'reserve-inventory':
        return {
          reservationId: 'res_wh_09184',
          warehouseCode: 'US-OHIO-03',
          itemsAllocated: 2,
          stockRemaining: 148,
        };
      case 'charge-payment-gateway':
        return {
          chargeId: 'ch_3N8f1e2eZvKYlo2C',
          amount: (run.inputPayload.totalAmountUsd as number) || 1990.0,
          captured: true,
          networkTransactionId: '984128941042',
        };
      case 'generate-shipping-manifest':
        return {
          trackingCode: '1Z9999999999999999',
          carrier: 'FedEx Priority Overnight',
          estimatedDelivery: 'Tomorrow by 10:30 AM',
          labelUrl: 'https://cdn.logistics.internal/labels/1Z9999.pdf',
        };
      case 'notify-customer-dispatched':
        return {
          notificationDispatched: true,
          channel: 'SMS_AND_EMAIL',
          deliveryStatus: 'DELIVERED',
        };
      case 'extract-pdf-text-and-ocr':
        return {
          extractedPages: 142,
          tablesIdentified: 18,
          confidenceScore: 0.94,
          characterCount: 421090,
        };
      case 'chunk-semantic-windows':
        return {
          totalChunks: 824,
          chunkingAlgorithm: 'semantic_boundary_512',
          avgTokensPerChunk: 504,
        };
      case 'generate-vector-embeddings':
        return {
          model: 'text-embedding-3-large',
          dimensions: 1536,
          totalVectorsGenerated: 824,
          averageConfidence: 0.86, // Triggers human review (<0.90)
        };
      case 'upsert-vector-database':
        return {
          collection: 'sec_filings_2025',
          upsertedCount: 824,
          indexHealth: 'HEALTHY',
          queryLatencyMs: 14,
        };
      case 'probe-preflight-health':
        return {
          allNodesReady: true,
          dnsLatencyP99Ms: 4,
          freeMemoryPercent: 48.2,
        };
      case 'shift-traffic-canary-10pct':
        return {
          virtualService: 'checkout-service',
          canaryWeight: 10,
          stableWeight: 90,
          canaryReplicasReady: 4,
        };
      case 'promote-traffic-100pct':
        return {
          virtualService: 'checkout-service',
          stableRevisionTeardown: 'COMPLETED',
          currentVersion: 'v2.14.0-rc3',
          liveTrafficPercent: 100,
        };
      default:
        return { status: 'OK', executedAt: Date.now() };
    }
  }

  // Pre-seed some realistic runs so the user lands on rich, active observability
  private seedInitialRuns() {
    // Run 1: Customer KYC in progress, currently WAITING_APPROVAL
    const r1 = this.triggerWorkflow('customer-kyc-onboarding', undefined, 'api');
    // Fast-forward verify-identity, screen-ofac, evaluate-credit
    const eVerify = r1.stepExecutions['verify-identity'];
    eVerify.status = 'completed';
    eVerify.startedAt = r1.startedAt;
    eVerify.finishedAt = r1.startedAt + 940;
    eVerify.durationMs = 940;
    eVerify.output = this.generateStepOutput('verify-identity', r1);
    eVerify.attempts = [{ attemptNumber: 1, startedAt: eVerify.startedAt, finishedAt: eVerify.finishedAt, durationMs: 940, status: 'completed', output: eVerify.output }];

    const eScreen = r1.stepExecutions['screen-ofac-sanctions'];
    eScreen.status = 'completed';
    eScreen.startedAt = eVerify.finishedAt;
    eScreen.finishedAt = eVerify.finishedAt + 1200;
    eScreen.durationMs = 1200;
    eScreen.output = this.generateStepOutput('screen-ofac-sanctions', r1);
    eScreen.attempts = [{ attemptNumber: 1, startedAt: eScreen.startedAt, finishedAt: eScreen.finishedAt, durationMs: 1200, status: 'completed', output: eScreen.output }];

    const eCredit = r1.stepExecutions['evaluate-credit-risk'];
    eCredit.status = 'completed';
    eCredit.startedAt = eVerify.finishedAt;
    eCredit.finishedAt = eVerify.finishedAt + 1050;
    eCredit.durationMs = 1050;
    eCredit.output = this.generateStepOutput('evaluate-credit-risk', r1);
    eCredit.attempts = [{ attemptNumber: 1, startedAt: eCredit.startedAt, finishedAt: eCredit.finishedAt, durationMs: 1050, status: 'completed', output: eCredit.output }];

    // Approval gate is waiting for human!
    const eApproval = r1.stepExecutions['compliance-officer-approval'];
    eApproval.status = 'waiting_approval';
    eApproval.startedAt = eScreen.finishedAt;
    eApproval.approvalData = {
      prompt: 'Entity risk score (0.76) exceeds automated threshold. Review beneficial ownership breakdown and sanctions scan results.',
      requestedAt: eScreen.finishedAt,
      expiresAt: eScreen.finishedAt + 86400000,
    };
    r1.status = 'waiting_approval';

    // Run 2: E-Commerce Fulfillment, completed with 1 retry on flaky payment API
    const defEcom = PRESET_WORKFLOWS.find((w) => w.id === 'ecommerce-fulfillment-saga')!;
    const r2Id = createId('run');
    const start2 = Date.now() - 145000;
    const r2: WorkflowRun = {
      id: r2Id,
      workflowId: defEcom.id,
      workflowName: defEcom.name,
      version: defEcom.version,
      status: 'completed',
      startedAt: start2,
      finishedAt: start2 + 8400,
      durationMs: 8400,
      taskQueue: defEcom.taskQueue,
      trigger: 'webhook',
      inputPayload: defEcom.samplePayload,
      stepExecutions: {
        'reserve-inventory': {
          stepId: 'reserve-inventory',
          status: 'completed',
          startedAt: start2 + 100,
          finishedAt: start2 + 1150,
          durationMs: 1050,
          currentAttempt: 1,
          output: this.generateStepOutput('reserve-inventory', { inputPayload: defEcom.samplePayload } as any),
          attempts: [{ attemptNumber: 1, startedAt: start2 + 100, finishedAt: start2 + 1150, durationMs: 1050, status: 'completed' }],
          logs: [{ timestamp: start2 + 100, level: 'info', message: 'Reserved SKU stock in OH warehouse.' }],
        },
        'charge-payment-gateway': {
          stepId: 'charge-payment-gateway',
          status: 'completed',
          startedAt: start2 + 1200,
          finishedAt: start2 + 4800,
          durationMs: 3600,
          currentAttempt: 2,
          output: this.generateStepOutput('charge-payment-gateway', { inputPayload: defEcom.samplePayload } as any),
          attempts: [
            {
              attemptNumber: 1,
              startedAt: start2 + 1200,
              finishedAt: start2 + 2100,
              durationMs: 900,
              status: 'failed',
              error: { name: 'PaymentGateway429', message: 'HTTP 429: Too Many Requests on payment gateway', retryable: true },
            },
            {
              attemptNumber: 2,
              startedAt: start2 + 3600,
              finishedAt: start2 + 4800,
              durationMs: 1200,
              status: 'completed',
            },
          ],
          logs: [
            { timestamp: start2 + 1200, level: 'info', message: 'Charge attempt #1 initiated.' },
            { timestamp: start2 + 2100, level: 'error', message: 'Stripe 429: Rate limit hit. Backoff 1500ms.' },
            { timestamp: start2 + 3600, level: 'info', message: 'Charge attempt #2 succeeded with idempotency key.' },
          ],
        },
        'generate-shipping-manifest': {
          stepId: 'generate-shipping-manifest',
          status: 'completed',
          startedAt: start2 + 4900,
          finishedAt: start2 + 6200,
          durationMs: 1300,
          currentAttempt: 1,
          output: this.generateStepOutput('generate-shipping-manifest', { inputPayload: defEcom.samplePayload } as any),
          attempts: [{ attemptNumber: 1, startedAt: start2 + 4900, finishedAt: start2 + 6200, durationMs: 1300, status: 'completed' }],
          logs: [{ timestamp: start2 + 4900, level: 'info', message: 'Created FedEx priority label 1Z9999.' }],
        },
        'notify-customer-dispatched': {
          stepId: 'notify-customer-dispatched',
          status: 'completed',
          startedAt: start2 + 6300,
          finishedAt: start2 + 7100,
          durationMs: 800,
          currentAttempt: 1,
          output: this.generateStepOutput('notify-customer-dispatched', { inputPayload: defEcom.samplePayload } as any),
          attempts: [{ attemptNumber: 1, startedAt: start2 + 6300, finishedAt: start2 + 7100, durationMs: 800, status: 'completed' }],
          logs: [{ timestamp: start2 + 6300, level: 'info', message: 'SMS and receipt PDF dispatched to customer.' }],
        },
        'compensate-release-inventory': {
          stepId: 'compensate-release-inventory',
          status: 'pending',
          attempts: [],
          currentAttempt: 0,
          logs: [],
        },
      },
      events: [
        { id: createId('evt'), timestamp: start2, type: 'WorkflowExecutionStarted', details: { id: defEcom.id } },
        { id: createId('evt'), timestamp: start2 + 100, type: 'ActivityTaskStarted', details: { stepId: 'reserve-inventory', attempt: 1 } },
        { id: createId('evt'), timestamp: start2 + 1150, type: 'ActivityTaskCompleted', details: { stepId: 'reserve-inventory' } },
        { id: createId('evt'), timestamp: start2 + 1200, type: 'ActivityTaskStarted', details: { stepId: 'charge-payment-gateway', attempt: 1 } },
        { id: createId('evt'), timestamp: start2 + 2100, type: 'ActivityTaskFailed', details: { stepId: 'charge-payment-gateway', error: 'HTTP 429' } },
        { id: createId('evt'), timestamp: start2 + 2101, type: 'RetryBackoffScheduled', details: { stepId: 'charge-payment-gateway', delayMs: 1500 } },
        { id: createId('evt'), timestamp: start2 + 3600, type: 'ActivityTaskStarted', details: { stepId: 'charge-payment-gateway', attempt: 2 } },
        { id: createId('evt'), timestamp: start2 + 4800, type: 'ActivityTaskCompleted', details: { stepId: 'charge-payment-gateway' } },
        { id: createId('evt'), timestamp: start2 + 4900, type: 'ActivityTaskStarted', details: { stepId: 'generate-shipping-manifest' } },
        { id: createId('evt'), timestamp: start2 + 6200, type: 'ActivityTaskCompleted', details: { stepId: 'generate-shipping-manifest' } },
        { id: createId('evt'), timestamp: start2 + 6300, type: 'ActivityTaskStarted', details: { stepId: 'notify-customer-dispatched' } },
        { id: createId('evt'), timestamp: start2 + 7100, type: 'ActivityTaskCompleted', details: { stepId: 'notify-customer-dispatched' } },
        { id: createId('evt'), timestamp: start2 + 7200, type: 'WorkflowExecutionCompleted', details: { status: 'fulfilled' } },
      ],
      outputPayload: { status: 'fulfilled', trackingNumber: '1Z9999999999999999', capturedUsd: 1990.0 },
    };
    this.runs.set(r2Id, r2);
  }

  private saveState() {
    try {
      const serializable = Array.from(this.runs.entries());
      localStorage.setItem('chronicle_orchestrator_runs_v1', JSON.stringify(serializable));
    } catch {
      // ignore localStorage quota errors
    }
  }

  private loadState() {
    try {
      const raw = localStorage.getItem('chronicle_orchestrator_runs_v1');
      if (raw) {
        const parsed = JSON.parse(raw);
        this.runs = new Map(parsed);
      }
    } catch {
      this.runs = new Map();
    }
  }

  public resetAll() {
    this.timers.forEach((t) => clearTimeout(t));
    this.timers.clear();
    this.runs.clear();
    localStorage.removeItem('chronicle_orchestrator_runs_v1');
    this.seedInitialRuns();
    this.notify();
  }
}

// Global orchestrator singleton instance
export const orchestrator = new WorkflowOrchestrator();
