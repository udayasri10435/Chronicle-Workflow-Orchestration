import { WorkflowDefinition } from '../types/workflow';

export const PRESET_WORKFLOWS: WorkflowDefinition[] = [
  {
    id: 'customer-kyc-onboarding',
    name: 'Customer Onboarding & KYC Compliance',
    description: 'Durable multi-stage onboarding workflow with sanctions screening, human compliance review gate, and tenant provisioning.',
    version: '1.4.0',
    category: 'Fintech & Compliance',
    taskQueue: 'compliance-queue',
    samplePayload: {
      userId: 'usr_8921f0a1',
      legalName: 'Elysian Technologies Corp',
      jurisdiction: 'US-DE',
      taxId: 'XX-XXX4910',
      incorporationYear: 2021,
      estimatedVolumeMonthlyUsd: 250000,
      riskAssessmentScore: 0.76, // Triggers human review threshold (>0.70)
      contactEmail: 'treasury@elysian.internal',
    },
    sdkCode: `import { createWorkflow } from '@chronicle/sdk';

export const customerKycOnboarding = createWorkflow({
  id: 'customer-kyc-onboarding',
  queue: 'compliance-queue',
  retryPolicy: { maxAttempts: 4, backoff: 'exponential' },
  handler: async ({ event, step }) => {
    const { userId, legalName, riskAssessmentScore } = event.data;

    // Step 1: Run identity & registry verification
    const identityResult = await step.run('verify-identity', async () => {
      return await regulatoryApi.verifyEntity({ legalName, jurisdiction: 'US-DE' });
    });

    // Step 2 & 3: Run sanctions screening and credit check in parallel
    const [sanctions, credit] = await Promise.all([
      step.run('screen-ofac-sanctions', { maxAttempts: 3 }, async () => {
        return await ofacClient.screenSubject({ entity: legalName });
      }),
      step.run('evaluate-credit-risk', async () => {
        return await creditBureau.scoreCompany({ entityId: identityResult.entityId });
      }),
    ]);

    // Step 4: Human-in-the-loop gate if risk score or sanctions require analyst audit
    let approvalDecision = { approved: true, riskTier: 'standard' };
    if (riskAssessmentScore > 0.70 || sanctions.flaggedMatches > 0) {
      approvalDecision = await step.waitForApproval('compliance-officer-approval', {
        prompt: 'High risk entity detected. Review KYC dossiers and determine onboarding clearance.',
        timeout: '24h',
        requiredRole: 'compliance-officer',
        payload: { userId, legalName, riskScore: riskAssessmentScore, sanctionsFlags: sanctions.flags }
      });
    }

    if (!approvalDecision.approved) {
      await step.run('notify-compliance-rejection', async () => {
        await mailer.sendNotice({ userId, reason: approvalDecision.reason });
      });
      return { status: 'rejected', reason: approvalDecision.reason };
    }

    // Step 5: Provision secure tenant cloud workspace
    const workspace = await step.run('provision-tenant-workspace', async () => {
      return await cloudOrchestrator.createTenantCluster({ orgId: userId });
    });

    // Step 6: Durable sleep before activating billing trial
    await step.sleep('trial-grace-period', '5s'); // Simulated grace period

    // Step 7: Finalize activation & dispatch welcome credentials
    const finalActivation = await step.run('dispatch-welcome-credentials', async () => {
      return await dispatchClient.sendActivationTokens({
        userId,
        workspaceUrl: workspace.clusterUrl,
      });
    });

    return { status: 'onboarded', workspaceId: workspace.id, tokenSent: true };
  },
});`,
    steps: [
      {
        id: 'verify-identity',
        name: 'Verify Business Entity & Registry',
        type: 'activity',
        description: 'Verify legal registration with state Delaware records and FinCEN database.',
        dependsOn: [],
        taskQueue: 'compliance-queue',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1200,
          backoffCoefficient: 2.0,
          maxIntervalMs: 15000,
        },
        codeSnippet: `const identityResult = await step.run('verify-identity', async () => {
  return await regulatoryApi.verifyEntity({ legalName, jurisdiction });
});`,
      },
      {
        id: 'screen-ofac-sanctions',
        name: 'OFAC Sanctions & PEP Screening',
        type: 'activity',
        description: 'Cross-reference global designated nationals lists, Interpol notices, and PEP directories.',
        dependsOn: ['verify-identity'],
        taskQueue: 'compliance-queue',
        retryPolicy: {
          maxAttempts: 4,
          initialIntervalMs: 1500,
          backoffCoefficient: 2.0,
          maxIntervalMs: 20000,
        },
        codeSnippet: `const sanctions = await step.run('screen-ofac-sanctions', async () => {
  return await ofacClient.screenSubject({ entity: legalName });
});`,
      },
      {
        id: 'evaluate-credit-risk',
        name: 'Credit Risk & Volume Underwriting',
        type: 'activity',
        description: 'Pull Dun & Bradstreet rating, assess projected monthly card volume default risk.',
        dependsOn: ['verify-identity'],
        taskQueue: 'compliance-queue',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1000,
          backoffCoefficient: 1.5,
          maxIntervalMs: 10000,
        },
        codeSnippet: `const credit = await step.run('evaluate-credit-risk', async () => {
  return await creditBureau.scoreCompany({ entityId: identityResult.entityId });
});`,
      },
      {
        id: 'compliance-officer-approval',
        name: 'Human Compliance Analyst Review',
        type: 'human_approval',
        description: 'Suspends workflow execution until Senior Compliance Officer reviews KYC risk score and signs off.',
        dependsOn: ['screen-ofac-sanctions', 'evaluate-credit-risk'],
        taskQueue: 'human-tasks',
        approvalPrompt: 'Entity risk score (0.76) exceeds automated threshold. Review beneficial ownership breakdown and sanctions scan results.',
        requiredRole: 'Senior Compliance Officer',
        codeSnippet: `const approval = await step.waitForApproval('compliance-officer-approval', {
  prompt: 'High risk entity detected. Review KYC dossiers and determine onboarding clearance.',
  timeout: '24h',
  requiredRole: 'compliance-officer'
});`,
      },
      {
        id: 'provision-tenant-workspace',
        name: 'Provision Isolated Tenant Cloud',
        type: 'activity',
        description: 'Spin up dedicated VPC peering, KMS encryption keys, and database schema partitions.',
        dependsOn: ['compliance-officer-approval'],
        taskQueue: 'infra-worker',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 2000,
          backoffCoefficient: 2.0,
          maxIntervalMs: 30000,
        },
        codeSnippet: `const workspace = await step.run('provision-tenant-workspace', async () => {
  return await cloudOrchestrator.createTenantCluster({ orgId: userId });
});`,
      },
      {
        id: 'trial-grace-period',
        name: 'Durable Sleep: Grace Period',
        type: 'sleep',
        description: 'Durable non-blocking timer suspending worker execution state until DNS propagation completes.',
        dependsOn: ['provision-tenant-workspace'],
        sleepDurationMs: 4000,
        codeSnippet: `await step.sleep('trial-grace-period', '4s');`,
      },
      {
        id: 'dispatch-welcome-credentials',
        name: 'Dispatch Production Cryptographic Keys',
        type: 'activity',
        description: 'Generate asymmetric API credentials, configure SSO SAML, and notify security team.',
        dependsOn: ['trial-grace-period'],
        taskQueue: 'mailer-worker',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1000,
          backoffCoefficient: 2.0,
          maxIntervalMs: 8000,
        },
        codeSnippet: `await step.run('dispatch-welcome-credentials', async () => {
  return await dispatchClient.sendActivationTokens({ userId });
});`,
      },
    ],
  },
  {
    id: 'ecommerce-fulfillment-saga',
    name: 'E-Commerce Payment & Order Fulfillment Saga',
    description: 'Distributed transaction with automated inventory reservation, payment charge retries, and compensation rollback.',
    version: '2.1.0',
    category: 'E-Commerce & Logistics',
    taskQueue: 'ecommerce-engine',
    samplePayload: {
      orderId: 'ord_9182390a',
      customerId: 'cust_48921',
      items: [
        { sku: 'HW-ROUTER-ENTERPRISE', quantity: 2, priceUsd: 899 },
        { sku: 'FIBER-CABLE-10M', quantity: 8, priceUsd: 24 },
      ],
      totalAmountUsd: 1990.0,
      currency: 'USD',
      shippingAddress: {
        line1: '742 Evergreen Terrace',
        city: 'Springfield',
        state: 'OR',
        postalCode: '97477',
      },
    },
    sdkCode: `import { createWorkflow } from '@chronicle/sdk';

export const orderFulfillmentSaga = createWorkflow({
  id: 'ecommerce-fulfillment-saga',
  queue: 'ecommerce-engine',
  handler: async ({ event, step }) => {
    const { orderId, items, totalAmountUsd, customerId } = event.data;

    // Step 1: Reserve inventory across warehouses
    const reservation = await step.run('reserve-inventory', async () => {
      return await warehouseClient.reserveStock({ orderId, items });
    });

    try {
      // Step 2: Authorize card with exponential backoff on banking flakiness
      const charge = await step.run('charge-payment-gateway', {
        maxAttempts: 5,
        backoff: 'exponential'
      }, async () => {
        return await stripe.charges.create({
          amount: totalAmountUsd * 100,
          currency: 'usd',
          idempotencyKey: \`pay_\${orderId}\`,
        });
      });

      // Step 3: Dispatch shipping label via 3PL logistics
      const shipment = await step.run('generate-shipping-manifest', async () => {
        return await logisticsProvider.createShipment({
          orderId,
          reservationId: reservation.reservationId,
        });
      });

      // Step 4: Send customer dispatch notification
      await step.run('notify-customer-dispatched', async () => {
        await emailService.sendOrderReceipt({ orderId, trackingNumber: shipment.trackingCode });
      });

      return { status: 'fulfilled', trackingNumber: shipment.trackingCode };
    } catch (error) {
      // Saga Compensation: Automatically release inventory if charge or shipping fails
      await step.run('compensate-release-inventory', async () => {
        await warehouseClient.releaseReservation({ reservationId: reservation.reservationId });
      });
      throw error;
    }
  },
});`,
    steps: [
      {
        id: 'reserve-inventory',
        name: 'Reserve Warehouse Inventory',
        type: 'activity',
        description: 'Lock SKU stock allocations in primary fulfillment distribution center.',
        dependsOn: [],
        taskQueue: 'warehouse-queue',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1000,
          backoffCoefficient: 2.0,
          maxIntervalMs: 10000,
        },
        codeSnippet: `const reservation = await step.run('reserve-inventory', async () => {
  return await warehouseClient.reserveStock({ orderId, items });
});`,
      },
      {
        id: 'charge-payment-gateway',
        name: 'Charge Payment Gateway (Flaky API)',
        type: 'activity',
        description: 'Authorize charge with idempotent merchant key. Handles bank rate limits with jittered backoff.',
        dependsOn: ['reserve-inventory'],
        taskQueue: 'payments-queue',
        retryPolicy: {
          maxAttempts: 4,
          initialIntervalMs: 1500,
          backoffCoefficient: 2.0,
          maxIntervalMs: 20000,
        },
        codeSnippet: `const charge = await step.run('charge-payment-gateway', { maxAttempts: 5 }, async () => {
  return await stripe.charges.create({ amount: totalAmountUsd * 100, idempotencyKey: \`pay_\${orderId}\` });
});`,
      },
      {
        id: 'generate-shipping-manifest',
        name: 'Dispatch 3PL Carrier Manifest',
        type: 'activity',
        description: 'Submit package dimensions to FedEx/DHL API, obtain tracking barcode and customs declaration.',
        dependsOn: ['charge-payment-gateway'],
        taskQueue: 'logistics-queue',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1200,
          backoffCoefficient: 2.0,
          maxIntervalMs: 10000,
        },
        codeSnippet: `const shipment = await step.run('generate-shipping-manifest', async () => {
  return await logisticsProvider.createShipment({ orderId, reservationId });
});`,
      },
      {
        id: 'notify-customer-dispatched',
        name: 'Send Customer Order Receipt',
        type: 'activity',
        description: 'Publish transactional push notification and dispatch order confirmation PDF.',
        dependsOn: ['generate-shipping-manifest'],
        taskQueue: 'mailer-worker',
        retryPolicy: {
          maxAttempts: 2,
          initialIntervalMs: 800,
          backoffCoefficient: 1.5,
          maxIntervalMs: 5000,
        },
        codeSnippet: `await step.run('notify-customer-dispatched', async () => {
  await emailService.sendOrderReceipt({ orderId, trackingNumber: shipment.trackingCode });
});`,
      },
      {
        id: 'compensate-release-inventory',
        name: 'Saga Compensation: Release Reserved Stock',
        type: 'compensation',
        description: 'Rollback action triggered automatically if payment or shipping fails downstream.',
        dependsOn: [],
        taskQueue: 'warehouse-queue',
        codeSnippet: `await step.run('compensate-release-inventory', async () => {
  await warehouseClient.releaseReservation({ reservationId: reservation.reservationId });
});`,
      },
    ],
  },
  {
    id: 'ai-doc-ingestion-embeddings',
    name: 'AI Document Ingestion & Chunk Embeddings',
    description: 'Extract multi-modal PDFs, generate rate-limited vector embeddings, and route low-confidence chunks to human review.',
    version: '3.0.2',
    category: 'AI & Data Pipeline',
    taskQueue: 'ai-data-engine',
    samplePayload: {
      documentId: 'doc_sec_10k_2025',
      documentUrl: 's3://corpora-vault/sec_filing_q4.pdf',
      fileSizeBytes: 14820941,
      pageCount: 142,
      chunkingStrategy: 'recursive_token_splitter',
      targetDimension: 1536,
      humanReviewConfidenceThreshold: 0.88,
    },
    sdkCode: `import { createWorkflow } from '@chronicle/sdk';

export const aiDocumentPipeline = createWorkflow({
  id: 'ai-doc-ingestion-embeddings',
  queue: 'ai-data-engine',
  handler: async ({ event, step }) => {
    const { documentId, documentUrl } = event.data;

    // Step 1: Extract PDF text and OCR tables
    const parsedDoc = await step.run('extract-pdf-text-and-ocr', async () => {
      return await documentParser.parseDocument({ url: documentUrl });
    });

    // Step 2: Semantic chunking into 512 token windows
    const chunks = await step.run('chunk-semantic-windows', async () => {
      return await textSplitter.splitTokens({ text: parsedDoc.rawText, maxTokens: 512 });
    });

    // Step 3: Embed vectors with rate-limit exponential backoff
    const embeddings = await step.run('generate-vector-embeddings', {
      maxAttempts: 6,
      backoff: 'exponential'
    }, async () => {
      return await embeddingModel.batchEmbed({ chunks: chunks.items });
    });

    // Step 4: Quality gate - Human QA review if embedding cosine confidence is borderline
    if (embeddings.averageConfidence < 0.90) {
      await step.waitForApproval('data-curator-quality-check', {
        prompt: 'Ambiguous table headers detected during OCR extraction. Review sample chunk embeddings before vector index commit.',
        requiredRole: 'ML Quality Lead',
        payload: { documentId, chunkCount: chunks.totalChunks, confidence: embeddings.averageConfidence }
      });
    }

    // Step 5: Commit to Milvus/Pinecone vector index
    await step.run('upsert-vector-database', async () => {
      await vectorStore.upsert({ collection: 'sec_filings_2025', vectors: embeddings.vectors });
    });

    return { status: 'indexed', totalVectors: chunks.totalChunks };
  },
});`,
    steps: [
      {
        id: 'extract-pdf-text-and-ocr',
        name: 'Parse PDF Layout & OCR Tables',
        type: 'activity',
        description: 'Extract multi-column layout, reconstruct Markdown tables, and strip headers.',
        dependsOn: [],
        taskQueue: 'ocr-workers',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1500,
          backoffCoefficient: 2.0,
          maxIntervalMs: 15000,
        },
        codeSnippet: `const parsedDoc = await step.run('extract-pdf-text-and-ocr', async () => {
  return await documentParser.parseDocument({ url: documentUrl });
});`,
      },
      {
        id: 'chunk-semantic-windows',
        name: 'Semantic Boundary Chunking',
        type: 'activity',
        description: 'Split token stream along sentence and header boundaries with 64 token overlap.',
        dependsOn: ['extract-pdf-text-and-ocr'],
        taskQueue: 'cpu-worker',
        retryPolicy: {
          maxAttempts: 2,
          initialIntervalMs: 800,
          backoffCoefficient: 1.5,
          maxIntervalMs: 5000,
        },
        codeSnippet: `const chunks = await step.run('chunk-semantic-windows', async () => {
  return await textSplitter.splitTokens({ text: parsedDoc.rawText, maxTokens: 512 });
});`,
      },
      {
        id: 'generate-vector-embeddings',
        name: 'Batch Embedding API (Rate Limit 429)',
        type: 'activity',
        description: 'Call embedding model with automatic retry on HTTP 429 quota exhaustion with jitter.',
        dependsOn: ['chunk-semantic-windows'],
        taskQueue: 'ai-inference-queue',
        retryPolicy: {
          maxAttempts: 5,
          initialIntervalMs: 1800,
          backoffCoefficient: 2.0,
          maxIntervalMs: 25000,
        },
        codeSnippet: `const embeddings = await step.run('generate-vector-embeddings', { maxAttempts: 6 }, async () => {
  return await embeddingModel.batchEmbed({ chunks: chunks.items });
});`,
      },
      {
        id: 'data-curator-quality-check',
        name: 'Human Data Curator QA Gate',
        type: 'human_approval',
        description: 'Approval gate for domain expert to verify chunk clarity when embedding confidence score dips.',
        dependsOn: ['generate-vector-embeddings'],
        taskQueue: 'human-tasks',
        approvalPrompt: 'OCR confidence score (0.84) below auto-publish threshold. Verify chunk segmentation before committing to production vector store.',
        requiredRole: 'ML Quality Lead',
        codeSnippet: `await step.waitForApproval('data-curator-quality-check', {
  prompt: 'Ambiguous table headers detected during OCR extraction.',
  requiredRole: 'ML Quality Lead'
});`,
      },
      {
        id: 'upsert-vector-database',
        name: 'Atomic Upsert to Vector Store',
        type: 'activity',
        description: 'Stream vector tuples, payload metadata, and HNSW graph links to production index.',
        dependsOn: ['data-curator-quality-check'],
        taskQueue: 'vector-queue',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1000,
          backoffCoefficient: 2.0,
          maxIntervalMs: 10000,
        },
        codeSnippet: `await step.run('upsert-vector-database', async () => {
  await vectorStore.upsert({ collection: 'sec_filings_2025', vectors: embeddings.vectors });
});`,
      },
    ],
  },
  {
    id: 'canary-infrastructure-rollout',
    name: 'Canary Deployment & Automated Health Rollback',
    description: 'Progressive traffic shifting with metric soak period, manual promotion approval, and automated abort.',
    version: '1.2.0',
    category: 'DevOps & Infrastructure',
    taskQueue: 'devops-runners',
    samplePayload: {
      releaseVersion: 'v2.14.0-rc3',
      gitSha: '7f9a241b8c',
      targetService: 'checkout-service',
      canaryWeightPercent: 10,
      soakDurationMinutes: 15,
      maxAllowedErrorRatePercent: 0.05,
    },
    sdkCode: `import { createWorkflow } from '@chronicle/sdk';

export const canaryDeployment = createWorkflow({
  id: 'canary-infrastructure-rollout',
  queue: 'devops-runners',
  handler: async ({ event, step }) => {
    const { releaseVersion, targetService } = event.data;

    // Step 1: Run pre-flight healthcheck probe
    await step.run('probe-preflight-health', async () => {
      await k8sClient.validateClusterState({ service: targetService });
    });

    // Step 2: Route 10% traffic to canary pods
    await step.run('shift-traffic-canary-10pct', async () => {
      await istioVirtualService.updateWeight({ service: targetService, canary: 10, prod: 90 });
    });

    // Step 3: Soak period monitoring error budgets
    await step.sleep('canary-soak-window', '5s');

    // Step 4: Human Site Reliability Engineer Promotion Signoff
    await step.waitForApproval('sre-rollout-approval', {
      prompt: 'Canary soak window elapsed with zero HTTP 5xx anomalies. Approve 100% traffic promotion to production.',
      requiredRole: 'Staff Site Reliability Engineer'
    });

    // Step 5: Complete 100% rollout
    await step.run('promote-traffic-100pct', async () => {
      await istioVirtualService.updateWeight({ service: targetService, canary: 100, prod: 0 });
    });

    return { status: 'deployed', releaseVersion };
  },
});`,
    steps: [
      {
        id: 'probe-preflight-health',
        name: 'Pre-flight Cluster Health Probe',
        type: 'activity',
        description: 'Verify node pod capacities, secret mount integrity, and DNS resolution latency.',
        dependsOn: [],
        taskQueue: 'devops-runners',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1000,
          backoffCoefficient: 2.0,
          maxIntervalMs: 8000,
        },
        codeSnippet: `await step.run('probe-preflight-health', async () => {
  await k8sClient.validateClusterState({ service: targetService });
});`,
      },
      {
        id: 'shift-traffic-canary-10pct',
        name: 'Shift 10% Traffic to Canary Subset',
        type: 'activity',
        description: 'Update Envoy ingress route table weights and spin up canary container replicas.',
        dependsOn: ['probe-preflight-health'],
        taskQueue: 'devops-runners',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1500,
          backoffCoefficient: 2.0,
          maxIntervalMs: 10000,
        },
        codeSnippet: `await step.run('shift-traffic-canary-10pct', async () => {
  await istioVirtualService.updateWeight({ service: targetService, canary: 10, prod: 90 });
});`,
      },
      {
        id: 'canary-soak-window',
        name: 'Durable Sleep: Soak & Metric Observation',
        type: 'sleep',
        description: 'Durable non-blocking wait while Datadog metrics gather latency P99 & HTTP error rate.',
        dependsOn: ['shift-traffic-canary-10pct'],
        sleepDurationMs: 4000,
        codeSnippet: `await step.sleep('canary-soak-window', '4s');`,
      },
      {
        id: 'sre-rollout-approval',
        name: 'SRE Lead Promotion Clearance',
        type: 'human_approval',
        description: 'Human gate for on-call SRE to verify Datadog dashboards before shifting 100% user traffic.',
        dependsOn: ['canary-soak-window'],
        taskQueue: 'human-tasks',
        approvalPrompt: 'Canary pods have served 14,200 requests with 0.002% error rate. Authorize 100% production traffic cutover.',
        requiredRole: 'Staff Site Reliability Engineer',
        codeSnippet: `await step.waitForApproval('sre-rollout-approval', {
  prompt: 'Canary soak window elapsed with zero HTTP 5xx anomalies. Approve 100% promotion.',
  requiredRole: 'Staff Site Reliability Engineer'
});`,
      },
      {
        id: 'promote-traffic-100pct',
        name: 'Cutover 100% Traffic & Drain Old Pods',
        type: 'activity',
        description: 'Flip ingress routing to 100% and initiate graceful teardown of previous revision.',
        dependsOn: ['sre-rollout-approval'],
        taskQueue: 'devops-runners',
        retryPolicy: {
          maxAttempts: 3,
          initialIntervalMs: 1200,
          backoffCoefficient: 2.0,
          maxIntervalMs: 12000,
        },
        codeSnippet: `await step.run('promote-traffic-100pct', async () => {
  await istioVirtualService.updateWeight({ service: targetService, canary: 100, prod: 0 });
});`,
      },
    ],
  },
];
