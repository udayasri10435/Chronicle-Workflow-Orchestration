import React, { useState } from 'react';
import {
  Server,
  Layers,
  Activity,
  Cpu,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Plus,
  RefreshCw,
} from 'lucide-react';
import { INITIAL_QUEUES, INITIAL_WORKERS, createId } from '../engine/orchestrator';
import { WorkerInstance, TaskQueueInfo } from '../types/workflow';

export const WorkerQueuesView: React.FC = () => {
  const [queues, setQueues] = useState<TaskQueueInfo[]>(INITIAL_QUEUES);
  const [workers, setWorkers] = useState<WorkerInstance[]>(INITIAL_WORKERS);

  const handleAddWorker = (queueName: string) => {
    const newWorker: WorkerInstance = {
      id: createId('worker'),
      hostname: `i-auto-${Math.random().toString(36).substring(2, 7)}`,
      queue: queueName,
      status: 'active',
      concurrency: 16,
      activeTasks: 0,
      tasksCompleted: 0,
      uptimeSeconds: 12,
      lastHeartbeat: Date.now(),
    };
    setWorkers((prev) => [newWorker, ...prev]);

    setQueues((prev) =>
      prev.map((q) => (q.name === queueName ? { ...q, activeWorkers: q.activeWorkers + 1 } : q))
    );
  };

  return (
    <div className="flex-1 w-full h-full bg-slate-950 p-6 overflow-y-auto custom-scrollbar">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Server className="w-5 h-5 text-indigo-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                Task Queues & Worker Fleet Telemetry
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Distributed task dispatch partitions, worker concurrency capacities, and real-time execution backlog
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg self-start">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Cluster: 5 active queues</span>
            <span className="text-slate-600">·</span>
            <span>{workers.length} nodes online</span>
          </div>
        </div>

        {/* Task Queues Grid */}
        <div>
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
            Active Task Queues
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {queues.map((q) => (
              <div
                key={q.name}
                className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-mono text-white truncate">{q.name}</span>
                  <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                    {q.type}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 block">Active Workers</span>
                    <span className="text-slate-200 font-bold">{q.activeWorkers} instances</span>
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 block">Queue Backlog</span>
                    <span className={q.pendingTasks > 4 ? 'text-amber-400 font-bold' : 'text-slate-200 font-bold'}>
                      {q.pendingTasks} tasks
                    </span>
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 block">Throughput (1h)</span>
                    <span className="text-emerald-400 font-bold">{q.completedTasksLastHour} done</span>
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 block">P95 Latency</span>
                    <span className="text-slate-200 font-bold tabular-nums">{q.p95LatencyMs}ms</span>
                  </div>
                </div>

                <button
                  onClick={() => handleAddWorker(q.name)}
                  className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1 border border-slate-700/80"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Scale Worker Replica</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Worker Fleet Nodes Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-indigo-400" />
              <span>Registered Worker Node Fleet</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">{workers.length} nodes polled</span>
          </div>

          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4 font-semibold">Instance Host</th>
                  <th className="py-2.5 px-4 font-semibold">Assigned Queue</th>
                  <th className="py-2.5 px-4 font-semibold">Status</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Concurrency</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Active Tasks</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Lifetime Done</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Uptime</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-300">
                {workers.map((w) => (
                  <tr key={w.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-4 font-semibold text-white flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      <span>{w.hostname}</span>
                    </td>
                    <td className="py-2.5 px-4 text-indigo-300">{w.queue}</td>
                    <td className="py-2.5 px-4">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded border uppercase font-medium ${
                          w.status === 'active'
                            ? 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10'
                            : 'text-amber-400 border-amber-500/30 bg-amber-500/10'
                        }`}
                      >
                        {w.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-right tabular-nums">{w.concurrency}</td>
                    <td className="py-2.5 px-4 text-right tabular-nums text-amber-300">{w.activeTasks}</td>
                    <td className="py-2.5 px-4 text-right tabular-nums text-slate-400">{w.tasksCompleted}</td>
                    <td className="py-2.5 px-4 text-right tabular-nums text-slate-400">
                      {(w.uptimeSeconds / 3600).toFixed(1)}h
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
