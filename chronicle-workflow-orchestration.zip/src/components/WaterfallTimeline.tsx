import React, { useMemo } from 'react';
import { Clock, AlertTriangle, CheckCircle2, RotateCw, ShieldAlert, Moon } from 'lucide-react';
import { WorkflowRun, StepDefinition } from '../types/workflow';
import { PRESET_WORKFLOWS } from '../engine/presets';

interface WaterfallTimelineProps {
  run: WorkflowRun;
  selectedStepId: string | null;
  onSelectStep: (stepId: string) => void;
}

export const WaterfallTimeline: React.FC<WaterfallTimelineProps> = ({
  run,
  selectedStepId,
  onSelectStep,
}) => {
  const def = useMemo(() => {
    return PRESET_WORKFLOWS.find((w) => w.id === run.workflowId);
  }, [run.workflowId]);

  // Compute total timeline span in milliseconds
  const timelineMetrics = useMemo(() => {
    const startTime = run.startedAt;
    const endTime = run.finishedAt || Date.now();
    const totalDurationMs = Math.max(1000, endTime - startTime);

    return { startTime, endTime, totalDurationMs };
  }, [run.startedAt, run.finishedAt]);

  const stepsList = useMemo(() => {
    if (!def) return [];
    return def.steps;
  }, [def]);

  return (
    <div className="w-full h-full bg-slate-950/70 p-4 overflow-y-auto custom-scrollbar flex flex-col">
      {/* Timeline Header & Scale */}
      <div className="mb-4 flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <h4 className="text-xs font-semibold text-slate-200">Execution Waterfall & Latency Breakdown</h4>
          <p className="text-[11px] text-slate-400">
            Durable step timelines, parallel branches, and backoff wait intervals
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
          <span>
            Total: <strong className="text-slate-200">{((timelineMetrics.totalDurationMs) / 1000).toFixed(2)}s</strong>
          </span>
          <span className="text-slate-600">|</span>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500/80"></span>
              Execution
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-amber-500/80"></span>
              Retry Backoff
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-indigo-500/80"></span>
              Human Gate
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-cyan-500/80"></span>
              Durable Sleep
            </span>
          </div>
        </div>
      </div>

      {/* Axis Scale Markers */}
      <div className="flex items-center pl-72 pr-4 mb-2 text-[10px] font-mono text-slate-500 justify-between border-b border-slate-800/40 pb-1">
        <span>0.0s</span>
        <span>{((timelineMetrics.totalDurationMs * 0.25) / 1000).toFixed(1)}s</span>
        <span>{((timelineMetrics.totalDurationMs * 0.5) / 1000).toFixed(1)}s</span>
        <span>{((timelineMetrics.totalDurationMs * 0.75) / 1000).toFixed(1)}s</span>
        <span>{((timelineMetrics.totalDurationMs) / 1000).toFixed(1)}s</span>
      </div>

      {/* Timeline Rows */}
      <div className="space-y-2">
        {stepsList.map((step) => {
          const exec = run.stepExecutions[step.id];
          const isSelected = selectedStepId === step.id;
          const status = exec?.status || 'pending';

          const stepStart = exec?.startedAt || timelineMetrics.startTime;
          const stepEnd = exec?.finishedAt || (status === 'running' || status === 'retrying' || status === 'sleeping' || status === 'waiting_approval' ? Date.now() : stepStart);
          
          const offsetMs = Math.max(0, stepStart - timelineMetrics.startTime);
          const durationMs = Math.max(50, stepEnd - stepStart);

          const leftPercent = Math.min(95, Math.max(0, (offsetMs / timelineMetrics.totalDurationMs) * 100));
          const widthPercent = Math.min(100 - leftPercent, Math.max(1.5, (durationMs / timelineMetrics.totalDurationMs) * 100));

          return (
            <div
              key={step.id}
              onClick={() => onSelectStep(step.id)}
              className={`flex items-center group cursor-pointer p-1.5 rounded-md transition-colors ${
                isSelected
                  ? 'bg-slate-800/80 border border-indigo-500/50'
                  : 'hover:bg-slate-900 border border-transparent'
              }`}
            >
              {/* Left Label column */}
              <div className="w-72 shrink-0 pr-4 flex items-center justify-between">
                <div className="flex items-center gap-2 truncate">
                  {status === 'completed' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                  {status === 'running' && <RotateCw className="w-3.5 h-3.5 text-indigo-400 animate-spin shrink-0" />}
                  {status === 'waiting_approval' && <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                  {status === 'sleeping' && <Moon className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                  {status === 'retrying' && <RotateCw className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                  {status === 'failed' && <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />}
                  {status === 'pending' && <div className="w-2.5 h-2.5 rounded-full bg-slate-700 shrink-0" />}

                  <span className="text-xs font-medium text-slate-300 group-hover:text-white truncate">
                    {step.name}
                  </span>
                </div>

                <div className="text-[11px] font-mono text-slate-400 shrink-0 pl-2">
                  {exec?.durationMs ? `${exec.durationMs}ms` : status === 'pending' ? '—' : status}
                </div>
              </div>

              {/* Right Gantt Bar Track */}
              <div className="flex-1 h-7 bg-slate-900/60 rounded border border-slate-800/80 relative overflow-hidden flex items-center">
                {/* Horizontal Guide Grid Lines */}
                <div className="absolute inset-0 flex justify-between pointer-events-none opacity-20">
                  <div className="border-r border-slate-700 h-full w-1/4"></div>
                  <div className="border-r border-slate-700 h-full w-1/4"></div>
                  <div className="border-r border-slate-700 h-full w-1/4"></div>
                  <div className="border-r border-slate-700 h-full w-1/4"></div>
                </div>

                {/* The actual Gantt Bar */}
                {status !== 'pending' && (
                  <div
                    style={{
                      left: `${leftPercent}%`,
                      width: `${widthPercent}%`,
                    }}
                    className={`absolute h-5 rounded transition-all duration-150 flex items-center px-1.5 text-[10px] font-mono text-white truncate shadow-xs ${
                      status === 'completed'
                        ? 'bg-emerald-600/90 border border-emerald-400/30'
                        : status === 'running'
                        ? 'bg-indigo-600 border border-indigo-400/50 animate-pulse'
                        : status === 'waiting_approval'
                        ? 'bg-amber-600/90 border border-amber-400/50'
                        : status === 'sleeping'
                        ? 'bg-cyan-600/90 border border-cyan-400/40'
                        : status === 'retrying'
                        ? 'bg-amber-600 border border-amber-400/50'
                        : status === 'failed'
                        ? 'bg-rose-600 border border-rose-400/40'
                        : 'bg-slate-700'
                    }`}
                    title={`${step.name} (${status}): offset ${(offsetMs / 1000).toFixed(2)}s, duration ${durationMs}ms`}
                  >
                    <span className="truncate">
                      {status === 'retrying'
                        ? `Retry #${exec?.currentAttempt}`
                        : status === 'waiting_approval'
                        ? 'Waiting human signoff'
                        : `${durationMs}ms`}
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
