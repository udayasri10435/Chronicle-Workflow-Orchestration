import React, { useState } from 'react';
import {
  ListFilter,
  Copy,
  Check,
  ChevronDown,
  ChevronRight,
  History,
  RotateCcw,
  Sparkles,
  Zap,
} from 'lucide-react';
import { WorkflowRun, ExecutionEvent } from '../types/workflow';

interface EventHistoryProps {
  run: WorkflowRun;
  onSelectEvent?: (event: ExecutionEvent, index: number) => void;
}

export const EventHistory: React.FC<EventHistoryProps> = ({ run }) => {
  const [filter, setFilter] = useState<'all' | 'activity' | 'retry' | 'approval' | 'lifecycle'>('all');
  const [expandedEventId, setExpandedEventId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [replayIndex, setReplayIndex] = useState<number | null>(null);

  const filteredEvents = run.events.filter((evt) => {
    if (filter === 'all') return true;
    if (filter === 'activity') return evt.type.startsWith('Activity');
    if (filter === 'retry') return evt.type.includes('Retry') || evt.type.includes('Failed');
    if (filter === 'approval') return evt.type.includes('Approval');
    if (filter === 'lifecycle') return evt.type.startsWith('Workflow') || evt.type.startsWith('Sleep');
    return true;
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const getEventBadgeColor = (type: string) => {
    if (type.includes('Completed') || type === 'WorkflowExecutionCompleted') {
      return 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
    }
    if (type.includes('Failed')) {
      return 'text-rose-400 border-rose-500/30 bg-rose-500/10';
    }
    if (type.includes('Retry')) {
      return 'text-amber-400 border-amber-500/30 bg-amber-500/10';
    }
    if (type.includes('Approval')) {
      return 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10';
    }
    if (type.includes('Sleep')) {
      return 'text-indigo-400 border-indigo-500/30 bg-indigo-500/10';
    }
    return 'text-slate-300 border-slate-700 bg-slate-800/60';
  };

  return (
    <div className="w-full h-full bg-slate-950/70 p-4 flex flex-col overflow-hidden">
      {/* Event Header & Time-Travel Slider */}
      <div className="pb-3 border-b border-slate-800 space-y-3 shrink-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-indigo-400" />
              <h4 className="text-xs font-semibold text-slate-200">
                Deterministic Execution Event Log
              </h4>
              <span className="text-[11px] font-mono text-slate-400">
                ({run.events.length} events recorded)
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Immutable event store with deterministic replay snapshots and payload lineage
            </p>
          </div>

          {/* Filter segment tabs */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-0.5 rounded-lg text-xs self-start">
            <button
              onClick={() => setFilter('all')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                filter === 'all' ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('activity')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                filter === 'activity' ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Activities
            </button>
            <button
              onClick={() => setFilter('retry')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                filter === 'retry' ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Retries & Errors
            </button>
            <button
              onClick={() => setFilter('approval')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                filter === 'approval' ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              HITL Approvals
            </button>
          </div>
        </div>

        {/* Replay Scrubbing Bar */}
        {run.events.length > 1 && (
          <div className="bg-slate-900/80 border border-slate-800/80 rounded-lg p-2 flex items-center gap-3">
            <span className="text-[11px] font-mono text-slate-400 shrink-0">
              Replay Debugger:
            </span>
            <input
              type="range"
              min="0"
              max={run.events.length - 1}
              value={replayIndex ?? run.events.length - 1}
              onChange={(e) => setReplayIndex(parseInt(e.target.value, 10))}
              className="flex-1 accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-mono text-indigo-400">
                Event #{(replayIndex ?? run.events.length - 1) + 1}/{run.events.length}
              </span>
              {replayIndex !== null && replayIndex < run.events.length - 1 && (
                <button
                  onClick={() => setReplayIndex(null)}
                  className="text-[10px] text-slate-400 hover:text-white underline font-mono"
                >
                  Live View
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Events Stream List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar mt-3 space-y-2 pr-1">
        {filteredEvents.map((evt, idx) => {
          const isExpanded = expandedEventId === evt.id;
          const offsetMs = evt.timestamp - run.startedAt;

          return (
            <div
              key={evt.id}
              className="bg-slate-900/60 border border-slate-800/80 rounded-lg overflow-hidden transition-colors hover:border-slate-700/80"
            >
              {/* Event Summary Row */}
              <div
                onClick={() => setExpandedEventId(isExpanded ? null : evt.id)}
                className="p-2.5 flex items-center justify-between cursor-pointer select-none gap-3"
              >
                <div className="flex items-center gap-2.5 truncate">
                  <span className="text-[10px] font-mono text-slate-500 w-6 shrink-0 text-right">
                    #{idx + 1}
                  </span>

                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded border font-medium shrink-0 ${getEventBadgeColor(
                      evt.type
                    )}`}
                  >
                    {evt.type}
                  </span>

                  <span className="text-xs font-medium text-slate-200 truncate">
                    {(evt.details.stepName as string) || (evt.details.stepId as string) || evt.type}
                  </span>

                  {Boolean(evt.details.attempt) && (
                    <span className="text-[11px] font-mono text-amber-400 shrink-0">
                      Attempt #{evt.details.attempt as number}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-[11px] font-mono text-slate-400 tabular-nums">
                    +{offsetMs}ms
                  </span>

                  {isExpanded ? (
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Event Payload Accordion Body */}
              {isExpanded && (
                <div className="bg-slate-950/90 border-t border-slate-800 p-3 text-xs font-mono text-slate-300 space-y-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>
                      Event ID: <strong className="text-slate-300">{evt.id}</strong>
                    </span>
                    <button
                      onClick={() => handleCopy(evt.id, JSON.stringify(evt.details, null, 2))}
                      className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition-colors"
                    >
                      {copiedId === evt.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy JSON</span>
                        </>
                      )}
                    </button>
                  </div>

                  <pre className="p-2.5 bg-slate-900/90 rounded border border-slate-800/80 text-[11px] text-emerald-300/90 overflow-x-auto custom-scrollbar max-h-48 leading-relaxed">
                    {JSON.stringify(evt.details, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
