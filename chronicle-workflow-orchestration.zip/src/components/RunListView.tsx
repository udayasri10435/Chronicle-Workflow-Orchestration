import React, { useState } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  ShieldAlert,
  Moon,
  Clock,
  Play,
  Pause,
  StopCircle,
  Copy,
  Check,
  ChevronRight,
  GitBranch,
  Layers,
  Flame,
  Maximize2,
} from 'lucide-react';
import { WorkflowRun, StepDefinition } from '../types/workflow';
import { PRESET_WORKFLOWS } from '../engine/presets';
import { DagGraph } from './DagGraph';
import { WaterfallTimeline } from './WaterfallTimeline';
import { EventHistory } from './EventHistory';
import { StepDetailDrawer } from './StepDetailDrawer';

interface RunListViewProps {
  runs: WorkflowRun[];
  activeRunId: string | null;
  onSelectRun: (runId: string) => void;
  onOpenTriggerModal: () => void;
  onOpenApproval: (stepId: string) => void;
  onManualRetry: (stepId: string) => void;
  onSkipStep: (stepId: string) => void;
  onTogglePause: (runId: string) => void;
  onTerminateRun: (runId: string) => void;
}

export const RunListView: React.FC<RunListViewProps> = ({
  runs,
  activeRunId,
  onSelectRun,
  onOpenTriggerModal,
  onOpenApproval,
  onManualRetry,
  onSkipStep,
  onTogglePause,
  onTerminateRun,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'running' | 'waiting_approval' | 'completed' | 'failed'>('all');
  const [activeTab, setActiveTab] = useState<'dag' | 'waterfall' | 'events' | 'state'>('dag');
  const [selectedStepId, setSelectedStepId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Current active run
  const activeRun = runs.find((r) => r.id === activeRunId) || runs[0];

  const activeDef = activeRun
    ? PRESET_WORKFLOWS.find((w) => w.id === activeRun.workflowId)
    : null;

  const selectedStepDef = activeDef && selectedStepId
    ? activeDef.steps.find((s) => s.id === selectedStepId)
    : null;

  const filteredRuns = runs.filter((run) => {
    const matchesSearch =
      run.workflowName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      run.id.toLowerCase().includes(searchTerm.toLowerCase());
    if (!matchesSearch) return false;
    if (statusFilter === 'all') return true;
    return run.status === statusFilter;
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const formatDuration = (ms?: number) => {
    if (!ms) return '0ms';
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(2)}s`;
  };

  return (
    <div className="flex-1 w-full h-full flex overflow-hidden bg-slate-950">
      {/* Left Column: Runs List Sidebar */}
      <div className="w-80 md:w-88 border-r border-slate-800 bg-slate-900/60 flex flex-col shrink-0">
        {/* Search & Filters */}
        <div className="p-3 border-b border-slate-800 space-y-2.5">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search run ID or workflow..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          {/* Status Segmented Filter */}
          <div className="flex items-center gap-1 overflow-x-auto custom-scrollbar pb-0.5 text-[11px]">
            {(['all', 'running', 'waiting_approval', 'completed', 'failed'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setStatusFilter(filter)}
                className={`px-2 py-1 rounded font-medium capitalize whitespace-nowrap transition-colors ${
                  statusFilter === filter
                    ? 'bg-slate-800 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                {filter === 'waiting_approval' ? 'Approval' : filter}
              </button>
            ))}
          </div>
        </div>

        {/* Runs List Items */}
        <div className="flex-1 overflow-y-auto custom-scrollbar divide-y divide-slate-800/60">
          {filteredRuns.length > 0 ? (
            filteredRuns.map((run) => {
              const isSelected = activeRun && run.id === activeRun.id;
              const duration = run.finishedAt
                ? run.finishedAt - run.startedAt
                : Date.now() - run.startedAt;

              return (
                <div
                  key={run.id}
                  onClick={() => onSelectRun(run.id)}
                  className={`p-3 cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-indigo-950/30 border-l-2 border-indigo-500 text-white'
                      : 'hover:bg-slate-800/40 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="font-mono text-slate-400 truncate max-w-[140px]">
                      {run.id}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      {new Date(run.startedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </span>
                  </div>

                  <h4 className="text-xs font-semibold text-slate-100 truncate mb-1.5">
                    {run.workflowName}
                  </h4>

                  <div className="flex items-center justify-between text-[11px] font-mono">
                    <div className="flex items-center gap-1.5">
                      {run.status === 'completed' && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      )}
                      {run.status === 'running' && (
                        <RotateCw className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
                      )}
                      {run.status === 'waiting_approval' && (
                        <ShieldAlert className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                      )}
                      {run.status === 'failed' && (
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                      )}
                      {run.status === 'paused' && (
                        <Pause className="w-3.5 h-3.5 text-amber-300" />
                      )}
                      {run.status === 'terminated' && (
                        <StopCircle className="w-3.5 h-3.5 text-slate-500" />
                      )}

                      <span className="capitalize text-slate-300">
                        {run.status === 'waiting_approval' ? 'approval gate' : run.status}
                      </span>
                    </div>

                    <span className="text-slate-400 tabular-nums">
                      {formatDuration(duration)}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="p-8 text-center text-xs text-slate-500 space-y-2">
              <p>No workflow runs matched the filter criteria.</p>
              <button
                onClick={onOpenTriggerModal}
                className="text-indigo-400 hover:text-indigo-300 underline font-medium"
              >
                Trigger a new workflow
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Center & Main Content Viewport */}
      {activeRun ? (
        <div className="flex-1 flex flex-col overflow-hidden bg-slate-950">
          {/* Active Run Header Bar */}
          <div className="p-4 border-b border-slate-800 bg-slate-900/80 flex flex-col md:flex-row md:items-center justify-between gap-3 shrink-0">
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="font-mono text-slate-400 flex items-center gap-1">
                  <span>{activeRun.id}</span>
                  <button
                    onClick={() => handleCopy('run-id', activeRun.id)}
                    className="text-slate-500 hover:text-slate-300"
                    title="Copy Run ID"
                  >
                    {copiedId === 'run-id' ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </button>
                </span>

                <span className="text-slate-600">·</span>
                <span className="text-slate-400">queue: <strong className="text-slate-200 font-mono">{activeRun.taskQueue}</strong></span>
                <span className="text-slate-600">·</span>
                <span className="text-slate-400">trigger: <strong className="text-slate-200 font-mono">{activeRun.trigger}</strong></span>
              </div>

              <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <span>{activeRun.workflowName}</span>
                <span className="text-xs font-mono text-slate-500 font-normal">v{activeRun.version}</span>
              </h2>
            </div>

            {/* Run Actions (Pause, Terminate, Status Badge) */}
            <div className="flex items-center gap-2 self-start md:self-auto">
              <div
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-mono font-medium ${
                  activeRun.status === 'completed'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : activeRun.status === 'running'
                    ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                    : activeRun.status === 'waiting_approval'
                    ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 animate-pulse'
                    : activeRun.status === 'failed'
                    ? 'bg-rose-500/10 border-rose-500/40 text-rose-300'
                    : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                {activeRun.status === 'running' && <RotateCw className="w-3.5 h-3.5 animate-spin" />}
                {activeRun.status === 'completed' && <CheckCircle2 className="w-3.5 h-3.5" />}
                {activeRun.status === 'waiting_approval' && <ShieldAlert className="w-3.5 h-3.5" />}
                {activeRun.status === 'failed' && <AlertTriangle className="w-3.5 h-3.5" />}
                <span className="uppercase">{activeRun.status}</span>
              </div>

              {(activeRun.status === 'running' || activeRun.status === 'paused') && (
                <button
                  onClick={() => onTogglePause(activeRun.id)}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg transition-colors border border-slate-700"
                  title={activeRun.status === 'paused' ? 'Resume execution' : 'Pause execution'}
                >
                  {activeRun.status === 'paused' ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                  <span>{activeRun.status === 'paused' ? 'Resume' : 'Pause'}</span>
                </button>
              )}

              {activeRun.status !== 'completed' && activeRun.status !== 'failed' && activeRun.status !== 'terminated' && (
                <button
                  onClick={() => onTerminateRun(activeRun.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors border border-transparent hover:border-rose-500/30"
                  title="Terminate workflow run"
                >
                  <StopCircle className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Observability Mode Segmented Tabs */}
          <div className="flex items-center justify-between px-4 border-b border-slate-800 bg-slate-900/40">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setActiveTab('dag')}
                className={`py-2 px-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
                  activeTab === 'dag'
                    ? 'border-indigo-500 text-white'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <GitBranch className="w-3.5 h-3.5" />
                <span>DAG Graph</span>
              </button>

              <button
                onClick={() => setActiveTab('waterfall')}
                className={`py-2 px-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
                  activeTab === 'waterfall'
                    ? 'border-indigo-500 text-white'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Waterfall Gantt</span>
              </button>

              <button
                onClick={() => setActiveTab('events')}
                className={`py-2 px-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
                  activeTab === 'events'
                    ? 'border-indigo-500 text-white'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Event Store ({activeRun.events.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('state')}
                className={`py-2 px-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
                  activeTab === 'state'
                    ? 'border-indigo-500 text-white'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>Cumulative State</span>
              </button>
            </div>

            <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-slate-400">
              <span>Steps: {Object.keys(activeRun.stepExecutions).length}</span>
              <span className="text-slate-700">|</span>
              <span>Duration: {formatDuration(activeRun.durationMs || (Date.now() - activeRun.startedAt))}</span>
            </div>
          </div>

          {/* Active View Surface + Step Inspector Drawer */}
          <div className="flex-1 flex overflow-hidden relative">
            {/* View Tabs */}
            <div className="flex-1 h-full overflow-hidden">
              {activeTab === 'dag' && (
                <DagGraph
                  run={activeRun}
                  selectedStepId={selectedStepId}
                  onSelectStep={(id) => setSelectedStepId(id)}
                  onOpenApproval={(id) => onOpenApproval(id)}
                  onManualRetry={(id) => onManualRetry(id)}
                />
              )}

              {activeTab === 'waterfall' && (
                <WaterfallTimeline
                  run={activeRun}
                  selectedStepId={selectedStepId}
                  onSelectStep={(id) => setSelectedStepId(id)}
                />
              )}

              {activeTab === 'events' && (
                <EventHistory run={activeRun} />
              )}

              {activeTab === 'state' && (
                <div className="w-full h-full p-6 overflow-y-auto custom-scrollbar space-y-6">
                  <div>
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                      Initial Input Payload
                    </h3>
                    <pre className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-xs font-mono text-cyan-300/90 overflow-x-auto custom-scrollbar leading-relaxed">
                      {JSON.stringify(activeRun.inputPayload, null, 2)}
                    </pre>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                      Final Output Payload
                    </h3>
                    <pre className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-xs font-mono text-emerald-300/90 overflow-x-auto custom-scrollbar leading-relaxed">
                      {activeRun.outputPayload
                        ? JSON.stringify(activeRun.outputPayload, null, 2)
                        : '// Workflow run has not completed yet'}
                    </pre>
                  </div>
                </div>
              )}
            </div>

            {/* Selected Step Detail Inspector Drawer */}
            {selectedStepDef && (
              <StepDetailDrawer
                step={selectedStepDef}
                exec={activeRun.stepExecutions[selectedStepDef.id]}
                run={activeRun}
                onClose={() => setSelectedStepId(null)}
                onRetryNow={(stepId) => onManualRetry(stepId)}
                onSkipStep={(stepId) => onSkipStep(stepId)}
                onOpenApproval={(stepId) => onOpenApproval(stepId)}
              />
            )}
          </div>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center p-8 text-center text-slate-400">
          <div>
            <h3 className="text-sm font-bold text-white mb-1">No Active Run Selected</h3>
            <p className="text-xs text-slate-500 mb-4">Choose a workflow run from the left panel or trigger a new one.</p>
            <button
              onClick={onOpenTriggerModal}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition-colors"
            >
              Trigger Workflow Run
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
