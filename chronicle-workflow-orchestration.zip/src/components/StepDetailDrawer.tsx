import React, { useState } from 'react';
import {
  X,
  RotateCw,
  FastForward,
  Copy,
  Check,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Moon,
  Terminal,
  Code,
  Sliders,
  ExternalLink,
} from 'lucide-react';
import { WorkflowRun, StepDefinition, StepExecution } from '../types/workflow';

interface StepDetailDrawerProps {
  step: StepDefinition;
  exec?: StepExecution;
  run: WorkflowRun;
  onClose: () => void;
  onRetryNow: (stepId: string) => void;
  onSkipStep: (stepId: string) => void;
  onOpenApproval: (stepId: string) => void;
}

export const StepDetailDrawer: React.FC<StepDetailDrawerProps> = ({
  step,
  exec,
  run,
  onClose,
  onRetryNow,
  onSkipStep,
  onOpenApproval,
}) => {
  const [activeTab, setActiveTab] = useState<'payload' | 'logs' | 'retries' | 'code'>('payload');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const status = exec?.status || 'pending';

  const handleCopy = (key: string, data: unknown) => {
    navigator.clipboard.writeText(typeof data === 'string' ? data : JSON.stringify(data, null, 2));
    setCopiedSection(key);
    setTimeout(() => setCopiedSection(null), 1800);
  };

  return (
    <div className="w-96 md:w-[480px] bg-slate-900 border-l border-slate-800 flex flex-col h-full shadow-2xl z-30 shrink-0">
      {/* Drawer Header */}
      <div className="p-4 border-b border-slate-800 flex items-start justify-between gap-3 bg-slate-900/90 backdrop-blur">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded border border-slate-700 bg-slate-800/80 text-slate-300 uppercase">
              {step.type}
            </span>
            <span className="text-xs font-mono text-slate-400">
              queue: <strong className="text-slate-200">{step.taskQueue || run.taskQueue}</strong>
            </span>
          </div>
          <h3 className="text-sm font-bold text-white tracking-tight">{step.name}</h3>
          <p className="text-xs text-slate-400 mt-0.5 leading-snug">{step.description}</p>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Status Bar & Primary Action CTA */}
      <div className="px-4 py-2.5 bg-slate-950/60 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {status === 'completed' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          {status === 'running' && <RotateCw className="w-4 h-4 text-indigo-400 animate-spin" />}
          {status === 'waiting_approval' && <ShieldAlert className="w-4 h-4 text-amber-400 animate-pulse" />}
          {status === 'sleeping' && <Moon className="w-4 h-4 text-cyan-400" />}
          {status === 'retrying' && <RotateCw className="w-4 h-4 text-amber-400" />}
          {status === 'failed' && <AlertTriangle className="w-4 h-4 text-rose-400" />}
          {status === 'pending' && <div className="w-3 h-3 rounded-full bg-slate-700" />}

          <div>
            <span className="text-xs font-medium capitalize text-slate-200">{status}</span>
            {exec?.durationMs && (
              <span className="text-[11px] font-mono text-slate-400 ml-1.5 tabular-nums">
                ({exec.durationMs}ms)
              </span>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {status === 'waiting_approval' && (
            <button
              onClick={() => onOpenApproval(step.id)}
              className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold rounded transition-colors shadow-xs"
            >
              Review Gate
            </button>
          )}

          {(status === 'failed' || status === 'retrying') && (
            <button
              onClick={() => onRetryNow(step.id)}
              className="flex items-center gap-1.5 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded transition-colors shadow-xs"
            >
              <RotateCw className="w-3 h-3" />
              <span>Retry Now</span>
            </button>
          )}

          {status !== 'completed' && status !== 'skipped' && (
            <button
              onClick={() => onSkipStep(step.id)}
              className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded transition-colors border border-slate-700"
              title="Inject mock success and advance DAG"
            >
              <FastForward className="w-3 h-3" />
              <span>Skip</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs Header */}
      <div className="flex items-center border-b border-slate-800 px-4 bg-slate-900/60">
        <button
          onClick={() => setActiveTab('payload')}
          className={`py-2 px-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'payload'
              ? 'border-indigo-500 text-white'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Payload & Output
        </button>

        <button
          onClick={() => setActiveTab('logs')}
          className={`py-2 px-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'logs'
              ? 'border-indigo-500 text-white'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Logs ({exec?.logs.length || 0})
        </button>

        <button
          onClick={() => setActiveTab('retries')}
          className={`py-2 px-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'retries'
              ? 'border-indigo-500 text-white'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Retries ({exec?.attempts.length || 0})
        </button>

        <button
          onClick={() => setActiveTab('code')}
          className={`py-2 px-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'code'
              ? 'border-indigo-500 text-white'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          SDK Code
        </button>
      </div>

      {/* Tab Content Body */}
      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-4">
        {/* TAB 1: Payload & Output */}
        {activeTab === 'payload' && (
          <div className="space-y-4">
            {/* Error Banner if step failed */}
            {exec?.error && (
              <div className="bg-rose-950/40 border border-rose-500/50 rounded-lg p-3 space-y-2">
                <div className="flex items-center gap-2 text-rose-300 font-semibold text-xs">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{exec.error.name}</span>
                </div>
                <p className="text-xs text-rose-200 font-mono leading-relaxed">{exec.error.message}</p>
                {exec.error.stack && (
                  <pre className="text-[10px] font-mono text-rose-300/80 bg-rose-950/80 p-2 rounded overflow-x-auto custom-scrollbar max-h-32">
                    {exec.error.stack}
                  </pre>
                )}
              </div>
            )}

            {/* Output Payload */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">Step Output Data</label>
                {Boolean(exec?.output) && (
                  <button
                    onClick={() => handleCopy('output', exec?.output)}
                    className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white"
                  >
                    {copiedSection === 'output' ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <Check className="w-3 h-3" /> Copied
                      </span>
                    ) : (
                      <span className="flex items-center gap-1">
                        <Copy className="w-3 h-3" /> Copy
                      </span>
                    )}
                  </button>
                )}
              </div>
              <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-emerald-300/90 overflow-x-auto custom-scrollbar max-h-56 leading-relaxed">
                {exec?.output ? JSON.stringify(exec.output, null, 2) : '// No output produced yet'}
              </pre>
            </div>

            {/* Input Payload */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">Step Input Data</label>
                <button
                  onClick={() => handleCopy('input', exec?.input || run.inputPayload)}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white"
                >
                  {copiedSection === 'input' ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Copied
                    </span>
                  ) : (
                    <span className="flex items-center gap-1">
                      <Copy className="w-3 h-3" /> Copy
                    </span>
                  )}
                </button>
              </div>
              <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-cyan-300/90 overflow-x-auto custom-scrollbar max-h-56 leading-relaxed">
                {JSON.stringify(exec?.input || run.inputPayload, null, 2)}
              </pre>
            </div>
          </div>
        )}

        {/* TAB 2: Execution Logs */}
        {activeTab === 'logs' && (
          <div className="space-y-2">
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 font-mono text-xs space-y-1.5 max-h-96 overflow-y-auto custom-scrollbar">
              {exec?.logs && exec.logs.length > 0 ? (
                exec.logs.map((log, index) => (
                  <div key={index} className="flex items-start gap-2 text-[11px] leading-relaxed">
                    <span className="text-slate-500 shrink-0">
                      {new Date(log.timestamp).toISOString().split('T')[1].slice(0, 8)}
                    </span>
                    <span
                      className={`font-semibold shrink-0 uppercase text-[10px] px-1 rounded ${
                        log.level === 'error'
                          ? 'text-rose-400 bg-rose-500/10'
                          : log.level === 'warn'
                          ? 'text-amber-400 bg-amber-500/10'
                          : 'text-indigo-400 bg-indigo-500/10'
                      }`}
                    >
                      {log.level}
                    </span>
                    <span
                      className={
                        log.level === 'error'
                          ? 'text-rose-300'
                          : log.level === 'warn'
                          ? 'text-amber-200'
                          : 'text-slate-300'
                      }
                    >
                      {log.message}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-slate-500 text-center py-6">
                  No log entries recorded for this step.
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: Retries Policy & Attempts */}
        {activeTab === 'retries' && (
          <div className="space-y-4">
            {/* Policy Parameters Grid */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 space-y-2">
              <h4 className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                <span>Configured Retry Policy</span>
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Max Attempts</span>
                  <span className="text-slate-200 font-bold">
                    {step.retryPolicy?.maxAttempts || 3} attempts
                  </span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Initial Interval</span>
                  <span className="text-slate-200 font-bold">
                    {step.retryPolicy?.initialIntervalMs || 1000}ms
                  </span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Backoff Coefficient</span>
                  <span className="text-slate-200 font-bold">
                    {step.retryPolicy?.backoffCoefficient || 2.0}x
                  </span>
                </div>
                <div className="bg-slate-900 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Max Interval</span>
                  <span className="text-slate-200 font-bold">
                    {step.retryPolicy?.maxIntervalMs || 20000}ms
                  </span>
                </div>
              </div>
            </div>

            {/* Attempts History */}
            <div>
              <h4 className="text-xs font-semibold text-slate-300 mb-2">Execution Attempt History</h4>
              <div className="space-y-2">
                {exec?.attempts && exec.attempts.length > 0 ? (
                  exec.attempts.map((attempt) => (
                    <div
                      key={attempt.attemptNumber}
                      className="bg-slate-950 border border-slate-800 rounded-lg p-3 space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-200 font-mono">
                          Attempt #{attempt.attemptNumber}
                        </span>
                        <span
                          className={`text-[10px] font-mono font-medium px-2 py-0.5 rounded border uppercase ${
                            attempt.status === 'completed'
                              ? 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10'
                              : attempt.status === 'failed'
                              ? 'text-rose-400 border-rose-500/30 bg-rose-500/10'
                              : 'text-indigo-400 border-indigo-500/30 bg-indigo-500/10'
                          }`}
                        >
                          {attempt.status}
                        </span>
                      </div>

                      <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between">
                        <span>
                          Duration:{' '}
                          <strong className="text-slate-300">
                            {attempt.durationMs ? `${attempt.durationMs}ms` : 'in flight...'}
                          </strong>
                        </span>
                        <span>{new Date(attempt.startedAt).toLocaleTimeString()}</span>
                      </div>

                      {attempt.error && (
                        <p className="text-[11px] text-rose-300 font-mono bg-rose-950/40 p-2 rounded border border-rose-900/60">
                          {attempt.error.message}
                        </p>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-slate-500 text-xs text-center py-4 bg-slate-950 rounded border border-slate-800">
                    No attempts logged yet.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SDK Code */}
        {activeTab === 'code' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>TypeScript SDK Definition</span>
              <button
                onClick={() => handleCopy('code', step.codeSnippet || '// No code snippet')}
                className="flex items-center gap-1 hover:text-white"
              >
                {copiedSection === 'code' ? (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Check className="w-3 h-3" /> Copied
                  </span>
                ) : (
                  <span className="flex items-center gap-1">
                    <Copy className="w-3 h-3" /> Copy
                  </span>
                )}
              </button>
            </div>
            <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-indigo-300/90 overflow-x-auto custom-scrollbar leading-relaxed">
              {step.codeSnippet || `// Step: ${step.id}\nawait step.run('${step.id}', async () => {\n  // Implementation\n});`}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
