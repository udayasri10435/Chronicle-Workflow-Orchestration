import React, { useState } from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  UserCheck,
  Edit3,
  X,
  Check,
} from 'lucide-react';
import { WorkflowRun, StepDefinition, StepExecution } from '../types/workflow';

interface HumanApprovalModalProps {
  run: WorkflowRun;
  step: StepDefinition;
  exec: StepExecution;
  onClose: () => void;
  onResolve: (decision: 'approved' | 'rejected', reason?: string, amendedPayload?: Record<string, unknown>) => void;
}

export const HumanApprovalModal: React.FC<HumanApprovalModalProps> = ({
  run,
  step,
  exec,
  onClose,
  onResolve,
}) => {
  const [decisionReason, setDecisionReason] = useState('');
  const [isEditingPayload, setIsEditingPayload] = useState(false);
  const [payloadText, setPayloadText] = useState(() =>
    JSON.stringify(run.inputPayload, null, 2)
  );
  const [jsonError, setJsonError] = useState<string | null>(null);

  const handleApprove = () => {
    let amended: Record<string, unknown> | undefined = undefined;
    if (isEditingPayload) {
      try {
        amended = JSON.parse(payloadText);
      } catch (err: any) {
        setJsonError(`Invalid JSON format: ${err.message}`);
        return;
      }
    }
    onResolve('approved', decisionReason || 'Analyst manual clearance passed invariants.', amended);
    onClose();
  };

  const handleReject = () => {
    onResolve('rejected', decisionReason || 'Analyst declined onboarding clearance based on risk policy.');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 bg-gradient-to-r from-amber-950/40 to-slate-900 border-b border-slate-800 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded border border-amber-500/30 bg-amber-500/10 text-amber-300 font-semibold uppercase">
                  Human-in-the-Loop Gate
                </span>
                <span className="text-xs font-mono text-slate-400">
                  Role: <strong className="text-slate-200">{step.requiredRole || 'Authorized Reviewer'}</strong>
                </span>
              </div>
              <h2 className="text-base font-bold text-white mt-1">{step.name}</h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 overflow-y-auto custom-scrollbar flex-1">
          {/* Prompt Description */}
          <div className="p-3 bg-amber-950/20 border border-amber-500/30 rounded-lg">
            <h4 className="text-xs font-semibold text-amber-300 mb-1 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>Review Directive</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              {exec.approvalData?.prompt || step.approvalPrompt || 'Review input payload and sanction matches before authorizing next execution phase.'}
            </p>
          </div>

          {/* Workflow & Applicant Context Summary */}
          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-500 text-[10px] block">Run ID</span>
              <span className="text-slate-200 truncate block">{run.id}</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-500 text-[10px] block">Suspension Deadline</span>
              <span className="text-emerald-400 font-sans font-medium flex items-center gap-1">
                <Clock className="w-3 h-3" /> 23h 58m remaining
              </span>
            </div>
          </div>

          {/* Payload Inspection & Amend Option */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <span>Entity Verification Payload</span>
                {isEditingPayload && (
                  <span className="text-[10px] font-mono text-amber-400">(Editable Mode)</span>
                )}
              </label>

              <button
                onClick={() => {
                  setIsEditingPayload(!isEditingPayload);
                  setJsonError(null);
                }}
                className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors"
              >
                <Edit3 className="w-3 h-3" />
                <span>{isEditingPayload ? 'Cancel Edit' : 'Amend Payload'}</span>
              </button>
            </div>

            {isEditingPayload ? (
              <div className="space-y-1.5">
                <textarea
                  value={payloadText}
                  onChange={(e) => {
                    setPayloadText(e.target.value);
                    setJsonError(null);
                  }}
                  rows={8}
                  className="w-full bg-slate-950 border border-indigo-500/60 rounded-lg p-3 text-xs font-mono text-emerald-300 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
                {jsonError && (
                  <p className="text-xs text-rose-400 font-mono">{jsonError}</p>
                )}
              </div>
            ) : (
              <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-cyan-300/90 overflow-x-auto custom-scrollbar max-h-48 leading-relaxed">
                {payloadText}
              </pre>
            )}
          </div>

          {/* Audit Note / Decision Reason */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Reviewer Audit Log Note (Optional)
            </label>
            <input
              type="text"
              value={decisionReason}
              onChange={(e) => setDecisionReason(e.target.value)}
              placeholder="e.g. Verified FinCEN registry certificate and cleared with AML tier 2 compliance"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Modal Footer: Action Buttons */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            Cancel
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleReject}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-lg transition-colors"
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>Reject Workflow</span>
            </button>

            <button
              onClick={handleApprove}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 active:bg-emerald-500 rounded-lg transition-colors shadow-sm shadow-emerald-500/20"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{isEditingPayload ? 'Amend & Approve' : 'Approve Step'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
