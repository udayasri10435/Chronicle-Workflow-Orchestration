import React from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  Clock,
  ArrowRight,
  UserCheck,
  AlertCircle,
  Play,
} from 'lucide-react';
import { WorkflowRun } from '../types/workflow';
import { PRESET_WORKFLOWS } from '../engine/presets';

interface ApprovalsViewProps {
  runs: WorkflowRun[];
  onOpenApproval: (runId: string, stepId: string) => void;
  onSelectRun: (runId: string) => void;
  onTriggerApprovalDemo: () => void;
}

export const ApprovalsView: React.FC<ApprovalsViewProps> = ({
  runs,
  onOpenApproval,
  onSelectRun,
  onTriggerApprovalDemo,
}) => {
  // Collect all step executions waiting for approval across all runs
  const pendingApprovals: Array<{
    run: WorkflowRun;
    stepId: string;
    stepName: string;
    prompt: string;
    requiredRole: string;
    requestedAt: number;
  }> = [];

  runs.forEach((run) => {
    const def = PRESET_WORKFLOWS.find((w) => w.id === run.workflowId);
    if (!def) return;

    Object.entries(run.stepExecutions).forEach(([stepId, exec]) => {
      if (exec.status === 'waiting_approval') {
        const stepDef = def.steps.find((s) => s.id === stepId);
        pendingApprovals.push({
          run,
          stepId,
          stepName: stepDef?.name || stepId,
          prompt: exec.approvalData?.prompt || stepDef?.approvalPrompt || 'Review required before continuing execution.',
          requiredRole: stepDef?.requiredRole || 'Authorized Reviewer',
          requestedAt: exec.approvalData?.requestedAt || run.startedAt,
        });
      }
    });
  });

  return (
    <div className="flex-1 w-full h-full bg-slate-950 p-6 overflow-y-auto custom-scrollbar">
      {/* View Header */}
      <div className="max-w-5xl mx-auto mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-white tracking-tight">
              Human-in-the-Loop Governance Center
            </h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-300 font-semibold">
              {pendingApprovals.length} Pending
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Suspended durable workflow state machines requiring explicit operator signoff, policy compliance, or payload amendment
          </p>
        </div>

        <button
          onClick={onTriggerApprovalDemo}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-xs self-start"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Launch KYC Approval Demo</span>
        </button>
      </div>

      <div className="max-w-5xl mx-auto">
        {pendingApprovals.length > 0 ? (
          <div className="space-y-3">
            {pendingApprovals.map((item) => (
              <div
                key={`${item.run.id}_${item.stepId}`}
                className="bg-slate-900 border border-amber-500/40 rounded-xl p-5 shadow-lg shadow-amber-950/10 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all hover:border-amber-500/70"
              >
                {/* Left details */}
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="font-mono text-[10px] uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                      Suspended
                    </span>
                    <span className="font-semibold text-slate-200">{item.run.workflowName}</span>
                    <span className="text-slate-600">·</span>
                    <span className="font-mono text-slate-400">{item.run.id}</span>
                  </div>

                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>{item.stepName}</span>
                  </h3>

                  <p className="text-xs text-slate-300 bg-slate-950/70 p-3 rounded-lg border border-slate-800 leading-relaxed">
                    {item.prompt}
                  </p>

                  <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-1">
                    <span>
                      Required Clearance: <strong className="text-slate-200">{item.requiredRole}</strong>
                    </span>
                    <span>·</span>
                    <span className="flex items-center gap-1 text-emerald-400 font-sans font-medium">
                      <Clock className="w-3.5 h-3.5" /> 23h 58m until auto-timeout
                    </span>
                  </div>
                </div>

                {/* Right Action buttons */}
                <div className="flex sm:flex-col items-center justify-end gap-2 shrink-0 border-t md:border-t-0 md:border-l border-slate-800 pt-3 md:pt-0 md:pl-5">
                  <button
                    onClick={() => onOpenApproval(item.run.id, item.stepId)}
                    className="w-full px-4 py-2 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 text-xs font-bold rounded-lg transition-colors shadow-sm shadow-amber-500/20 text-center"
                  >
                    Review & Decide
                  </button>

                  <button
                    onClick={() => onSelectRun(item.run.id)}
                    className="w-full px-3 py-1.5 text-xs text-slate-400 hover:text-white rounded-lg transition-colors flex items-center justify-center gap-1 hover:bg-slate-800"
                  >
                    <span>Inspect DAG</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-12 text-center max-w-xl mx-auto space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-white">All Workflows Unblocked</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              No workflow runs are currently suspended awaiting human approval. All active instances are processing autonomously through task queues.
            </p>
            <div className="pt-2">
              <button
                onClick={onTriggerApprovalDemo}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition-colors inline-flex items-center gap-1.5 shadow-xs"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Simulate High-Risk Compliance Gate</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
