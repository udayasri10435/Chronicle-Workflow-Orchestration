import React, { useState } from 'react';
import {
  X,
  Play,
  Sparkles,
  Sliders,
  Flame,
  Check,
  Workflow as WorkflowIcon,
  Layers,
  Clock,
  Radio,
} from 'lucide-react';
import { PRESET_WORKFLOWS } from '../engine/presets';
import { WorkflowDefinition } from '../types/workflow';

interface TriggerWorkflowModalProps {
  onClose: () => void;
  onTrigger: (workflowId: string, payload: Record<string, unknown>, trigger: 'manual' | 'api' | 'webhook' | 'cron') => void;
  chaosEnabled: boolean;
}

export const TriggerWorkflowModal: React.FC<TriggerWorkflowModalProps> = ({
  onClose,
  onTrigger,
  chaosEnabled,
}) => {
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string>(
    PRESET_WORKFLOWS[0].id
  );
  const [triggerType, setTriggerType] = useState<'manual' | 'api' | 'webhook' | 'cron'>('manual');

  const selectedDef = PRESET_WORKFLOWS.find((w) => w.id === selectedWorkflowId)!;

  const [payloadText, setPayloadText] = useState(() =>
    JSON.stringify(selectedDef.samplePayload, null, 2)
  );
  const [jsonError, setJsonError] = useState<string | null>(null);

  const handleSelectWorkflow = (def: WorkflowDefinition) => {
    setSelectedWorkflowId(def.id);
    setPayloadText(JSON.stringify(def.samplePayload, null, 2));
    setJsonError(null);
  };

  const handleLaunch = () => {
    try {
      const parsed = JSON.parse(payloadText);
      onTrigger(selectedWorkflowId, parsed, triggerType);
      onClose();
    } catch (err: any) {
      setJsonError(`Invalid JSON payload: ${err.message}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Play className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight">
                Trigger New Durable Workflow Run
              </h2>
              <p className="text-xs text-slate-400">
                Instantiate deterministic state machine with durable retry policies
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-5 overflow-y-auto custom-scrollbar flex-1">
          {/* Preset Selector Cards */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              Select Workflow Blueprint
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              {PRESET_WORKFLOWS.map((wf) => {
                const isSelected = wf.id === selectedWorkflowId;
                return (
                  <div
                    key={wf.id}
                    onClick={() => handleSelectWorkflow(wf)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-indigo-950/30 border-indigo-500/80 shadow-xs'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono text-indigo-400 font-semibold uppercase">
                        {wf.category}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500">v{wf.version}</span>
                    </div>
                    <h3 className="text-xs font-bold text-slate-100">{wf.name}</h3>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {wf.description}
                    </p>
                    <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400">
                      <span>{wf.steps.length} steps</span>
                      <span>·</span>
                      <span className="truncate">{wf.taskQueue}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Trigger Context & Ingress Source */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Ingress Trigger Source
              </label>
              <div className="grid grid-cols-4 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                {(['manual', 'api', 'webhook', 'cron'] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTriggerType(t)}
                    className={`py-1 text-xs font-mono capitalize rounded transition-colors ${
                      triggerType === t
                        ? 'bg-slate-800 text-white font-medium shadow-xs'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Execution Task Queue
              </label>
              <div className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-300 flex items-center justify-between">
                <span>{selectedDef.taskQueue}</span>
                <span className="text-[10px] text-emerald-400 font-sans font-medium">active workers: 4</span>
              </div>
            </div>
          </div>

          {/* JSON Payload Editor */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <span>Input Payload (JSON)</span>
                <span className="text-[11px] font-mono text-slate-500 font-normal">
                  Passed to workflow handler
                </span>
              </label>
              <button
                type="button"
                onClick={() => setPayloadText(JSON.stringify(selectedDef.samplePayload, null, 2))}
                className="text-xs text-indigo-400 hover:text-indigo-300"
              >
                Reset to Sample
              </button>
            </div>

            <textarea
              value={payloadText}
              onChange={(e) => {
                setPayloadText(e.target.value);
                setJsonError(null);
              }}
              rows={9}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-cyan-300/90 focus:outline-hidden focus:border-indigo-500"
            />
            {jsonError && (
              <p className="text-xs text-rose-400 font-mono mt-1">{jsonError}</p>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            Cancel
          </button>

          <button
            onClick={handleLaunch}
            className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-lg transition-colors shadow-sm shadow-indigo-600/30"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Dispatch Workflow Run</span>
          </button>
        </div>
      </div>
    </div>
  );
};
