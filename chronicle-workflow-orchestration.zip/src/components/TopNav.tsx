import React from 'react';
import {
  Play,
  Flame,
  RotateCcw,
  ShieldAlert,
  Server,
  Code2,
  Workflow as WorkflowIcon,
  CheckCircle2,
} from 'lucide-react';
import { WorkflowRun } from '../types/workflow';

interface TopNavProps {
  activeView: 'runs' | 'approvals' | 'queues' | 'sdk';
  onSelectView: (view: 'runs' | 'approvals' | 'queues' | 'sdk') => void;
  pendingApprovalsCount: number;
  onOpenTriggerModal: () => void;
  chaosMode: boolean;
  onToggleChaos: () => void;
  onResetEngine: () => void;
  activeRun?: WorkflowRun;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeView,
  onSelectView,
  pendingApprovalsCount,
  onOpenTriggerModal,
  chaosMode,
  onToggleChaos,
  onResetEngine,
  activeRun,
}) => {
  return (
    <header className="h-14 bg-slate-900/90 backdrop-blur border-b border-slate-800 px-4 md:px-6 flex items-center justify-between z-30 shrink-0">
      {/* Zone 1: Wordmark Brand Title */}
      <div className="flex items-center gap-3">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onSelectView('runs');
          }}
          className="text-base font-bold tracking-tight text-white flex items-center gap-2 hover:text-indigo-400 transition-colors"
        >
          <div className="w-6 h-6 rounded bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center text-white text-xs font-mono font-bold shadow-sm shadow-indigo-500/20">
            C
          </div>
          <span>Chronicle</span>
        </a>

        {/* Quiet breadcrumb / environment context */}
        <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400 font-mono pl-3 border-l border-slate-800">
          <span className="text-slate-300">production-cluster-01</span>
          <span aria-hidden="true" className="text-slate-600">/</span>
          <span className="text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            healthy
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="flex items-center gap-1 sm:gap-2">
        <button
          onClick={() => onSelectView('runs')}
          className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            activeView === 'runs'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <WorkflowIcon className="w-3.5 h-3.5" />
          <span>Workflow Runs</span>
        </button>

        <button
          onClick={() => onSelectView('approvals')}
          className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors relative ${
            activeView === 'approvals'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
          <span>Approvals</span>
          {pendingApprovalsCount > 0 && (
            <span className="px-1.5 py-0.2 bg-amber-500/20 text-amber-300 font-mono text-[10px] rounded font-semibold border border-amber-500/30">
              {pendingApprovalsCount}
            </span>
          )}
        </button>

        <button
          onClick={() => onSelectView('queues')}
          className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            activeView === 'queues'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Server className="w-3.5 h-3.5" />
          <span>Queues & Workers</span>
        </button>

        <button
          onClick={() => onSelectView('sdk')}
          className={`hidden md:flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            activeView === 'sdk'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>TypeScript SDK</span>
        </button>
      </nav>

      {/* Zone 3: Actions & Controls */}
      <div className="flex items-center gap-2">
        {/* Chaos Injection Simulator */}
        <button
          onClick={onToggleChaos}
          title={chaosMode ? 'Chaos mode enabled: 35% simulated step flakiness & rate limits' : 'Enable simulated transient failures & 429 backoff'}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md border transition-all ${
            chaosMode
              ? 'bg-rose-500/10 border-rose-500/40 text-rose-300 shadow-xs'
              : 'bg-slate-800/80 border-slate-700/80 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Flame className={`w-3.5 h-3.5 ${chaosMode ? 'text-rose-400 animate-pulse' : 'text-slate-500'}`} />
          <span className="hidden sm:inline">Fault Injection:</span>
          <span className="font-mono text-[11px] font-semibold">{chaosMode ? 'ACTIVE' : 'OFF'}</span>
        </button>

        {/* Reset State button */}
        <button
          onClick={onResetEngine}
          title="Reset orchestrator state and re-seed clean runs"
          className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-md transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>

        {/* Primary CTA: Launch Workflow */}
        <button
          onClick={onOpenTriggerModal}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-md transition-colors shadow-sm shadow-indigo-600/30 whitespace-nowrap"
        >
          <Play className="w-3 h-3 fill-current" />
          <span>Trigger Workflow</span>
        </button>
      </div>
    </header>
  );
};
