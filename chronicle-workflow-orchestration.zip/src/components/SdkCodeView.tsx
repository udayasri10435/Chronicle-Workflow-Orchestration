import React, { useState } from 'react';
import { Code2, Copy, Check, Terminal, BookOpen, Layers, ShieldCheck, Zap } from 'lucide-react';
import { PRESET_WORKFLOWS } from '../engine/presets';

export const SdkCodeView: React.FC = () => {
  const [selectedWorkflowId, setSelectedWorkflowId] = useState(PRESET_WORKFLOWS[0].id);
  const [copied, setCopied] = useState(false);

  const selectedDef = PRESET_WORKFLOWS.find((w) => w.id === selectedWorkflowId)!;

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedDef.sdkCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 w-full h-full bg-slate-950 p-6 overflow-y-auto custom-scrollbar">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Code2 className="w-5 h-5 text-indigo-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                TypeScript Workflow SDK Reference
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Author fault-tolerant, durable workflows as standard async/await TypeScript functions with zero state machine boilerplate
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg self-start">
            <span className="text-indigo-400">@chronicle/sdk</span>
            <span>v2.4.0</span>
          </div>
        </div>

        {/* Workflow Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto custom-scrollbar border-b border-slate-800 pb-2">
          {PRESET_WORKFLOWS.map((wf) => (
            <button
              key={wf.id}
              onClick={() => setSelectedWorkflowId(wf.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                wf.id === selectedWorkflowId
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              {wf.name}
            </button>
          ))}
        </div>

        {/* Code & Architectural Feature Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Code Window */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl flex flex-col">
            <div className="p-3 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400 flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 text-indigo-400" />
                <span>workflows/{selectedDef.id}.ts</span>
              </span>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy SDK Code</span>
                  </>
                )}
              </button>
            </div>

            <pre className="p-4 bg-slate-950 font-mono text-xs text-indigo-200/90 overflow-x-auto custom-scrollbar leading-relaxed flex-1 max-h-[600px]">
              {selectedDef.sdkCode}
            </pre>
          </div>

          {/* Core Durable Principles Card */}
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Durable Execution Guarantees</span>
              </h3>

              <div className="space-y-3 text-xs text-slate-300">
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                  <h4 className="font-semibold text-white font-mono flex items-center gap-1.5">
                    <span className="text-indigo-400">step.run()</span>
                  </h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Executes activities with automatic memoization. On process crash or worker failure, completed steps are replayed instantly from cached event history without re-executing.
                  </p>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                  <h4 className="font-semibold text-white font-mono flex items-center gap-1.5">
                    <span className="text-amber-400">step.waitForApproval()</span>
                  </h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Suspends workflow execution in the durable event store. Consumes 0 CPU and 0 worker memory while waiting hours or weeks for human compliance authorization.
                  </p>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                  <h4 className="font-semibold text-white font-mono flex items-center gap-1.5">
                    <span className="text-cyan-400">step.sleep()</span>
                  </h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Durable timers scheduled in database queues. Survives container deployments, Kubernetes rolling restarts, and infrastructure maintenance windows.
                  </p>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                  <h4 className="font-semibold text-white font-mono flex items-center gap-1.5">
                    <span className="text-rose-400">Saga Compensations</span>
                  </h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Standard JavaScript <code className="text-slate-200">try/catch</code> blocks automatically trigger durable compensation rollback routines if downstream services reject transactions.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
