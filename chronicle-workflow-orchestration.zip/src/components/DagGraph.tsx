import React, { useMemo } from 'react';
import {
  CheckCircle2,
  Clock,
  AlertTriangle,
  RotateCw,
  ShieldAlert,
  Moon,
  Zap,
  Play,
  ArrowRight,
  Maximize2,
  Minus,
  Plus,
} from 'lucide-react';
import { WorkflowRun, StepDefinition, StepExecution } from '../types/workflow';
import { PRESET_WORKFLOWS } from '../engine/presets';

interface DagGraphProps {
  run: WorkflowRun;
  selectedStepId: string | null;
  onSelectStep: (stepId: string) => void;
  onOpenApproval: (stepId: string) => void;
  onManualRetry: (stepId: string) => void;
}

interface NodeLayout {
  step: StepDefinition;
  exec?: StepExecution;
  col: number;
  row: number;
  x: number;
  y: number;
  width: number;
  height: number;
}

export const DagGraph: React.FC<DagGraphProps> = ({
  run,
  selectedStepId,
  onSelectStep,
  onOpenApproval,
  onManualRetry,
}) => {
  const [zoom, setZoom] = React.useState(1);

  const def = useMemo(() => {
    return PRESET_WORKFLOWS.find((w) => w.id === run.workflowId);
  }, [run.workflowId]);

  // Compute topological layout for DAG nodes
  const layout = useMemo(() => {
    if (!def) return { nodes: [], edges: [], width: 900, height: 420 };

    const nodeWidth = 240;
    const nodeHeight = 88;
    const colSpacing = 80;
    const rowSpacing = 40;

    // Determine column depth based on dependsOn
    const depths = new Map<string, number>();

    const getDepth = (id: string, visited = new Set<string>()): number => {
      if (depths.has(id)) return depths.get(id)!;
      if (visited.has(id)) return 0; // prevent cycle
      visited.add(id);

      const step = def.steps.find((s) => s.id === id);
      if (!step || step.dependsOn.length === 0) {
        depths.set(id, 0);
        return 0;
      }

      let maxParentDepth = 0;
      for (const parentId of step.dependsOn) {
        maxParentDepth = Math.max(maxParentDepth, getDepth(parentId, visited) + 1);
      }
      depths.set(id, maxParentDepth);
      return maxParentDepth;
    };

    def.steps.forEach((s) => getDepth(s.id));

    // Group steps by column
    const columns: StepDefinition[][] = [];
    def.steps.forEach((step) => {
      const col = depths.get(step.id) || 0;
      if (!columns[col]) columns[col] = [];
      columns[col].push(step);
    });

    const nodes: NodeLayout[] = [];
    let maxColY = 0;

    columns.forEach((colSteps, colIndex) => {
      colSteps.forEach((step, rowIndex) => {
        const x = 40 + colIndex * (nodeWidth + colSpacing);
        const y = 50 + rowIndex * (nodeHeight + rowSpacing);
        maxColY = Math.max(maxColY, y + nodeHeight);

        nodes.push({
          step,
          exec: run.stepExecutions[step.id],
          col: colIndex,
          row: rowIndex,
          x,
          y,
          width: nodeWidth,
          height: nodeHeight,
        });
      });
    });

    // Compute edge coordinates
    const edges: Array<{
      id: string;
      from: NodeLayout;
      to: NodeLayout;
      isActive: boolean;
      isCompleted: boolean;
    }> = [];

    nodes.forEach((targetNode) => {
      targetNode.step.dependsOn.forEach((depId) => {
        const sourceNode = nodes.find((n) => n.step.id === depId);
        if (sourceNode) {
          const isCompleted = sourceNode.exec?.status === 'completed';
          const isActive = targetNode.exec?.status === 'running' || targetNode.exec?.status === 'retrying';
          edges.push({
            id: `${sourceNode.step.id}->${targetNode.step.id}`,
            from: sourceNode,
            to: targetNode,
            isActive,
            isCompleted,
          });
        }
      });
    });

    const totalWidth = Math.max(900, 80 + columns.length * (nodeWidth + colSpacing));
    const totalHeight = Math.max(400, maxColY + 80);

    return { nodes, edges, width: totalWidth, height: totalHeight };
  }, [def, run.stepExecutions]);

  return (
    <div className="relative w-full h-full bg-slate-950/60 overflow-hidden select-none flex flex-col">
      {/* Zoom / Canvas Controls */}
      <div className="absolute top-3 right-3 z-20 flex items-center gap-1 bg-slate-900/90 border border-slate-800 p-1 rounded-lg backdrop-blur">
        <button
          onClick={() => setZoom((z) => Math.max(0.6, z - 0.1))}
          className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Zoom Out"
        >
          <Minus className="w-3.5 h-3.5" />
        </button>
        <span className="text-[11px] font-mono text-slate-400 px-1 min-w-[36px] text-center">
          {Math.round(zoom * 100)}%
        </span>
        <button
          onClick={() => setZoom((z) => Math.min(1.4, z + 0.1))}
          className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Zoom In"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => setZoom(1)}
          className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors ml-1 border-l border-slate-800 pl-1.5"
          title="Reset View"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Canvas Area */}
      <div className="flex-1 w-full h-full overflow-auto p-4 custom-scrollbar">
        <div
          style={{
            transform: `scale(${zoom})`,
            transformOrigin: 'top left',
            width: layout.width,
            height: layout.height,
          }}
          className="relative transition-transform duration-100 ease-out"
        >
          {/* Subtle Grid Pattern */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20">
            <defs>
              <pattern id="dag-grid" width="24" height="24" patternUnits="userSpaceOnUse">
                <circle cx="2" cy="2" r="1" fill="#475569" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#dag-grid)" />
          </svg>

          {/* SVG Connecting Edges */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
            <defs>
              <linearGradient id="edge-active-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#6366f1" />
              </linearGradient>
            </defs>
            {layout.edges.map((edge) => {
              const startX = edge.from.x + edge.from.width;
              const startY = edge.from.y + edge.from.height / 2;
              const endX = edge.to.x;
              const endY = edge.to.y + edge.to.height / 2;
              const midX = (startX + endX) / 2;

              // Cubic bezier curve path
              const pathD = `M ${startX} ${startY} C ${midX} ${startY}, ${midX} ${endY}, ${endX} ${endY}`;

              return (
                <g key={edge.id}>
                  {/* Background shadow stroke */}
                  <path
                    d={pathD}
                    fill="none"
                    stroke="#1e293b"
                    strokeWidth="3"
                  />
                  {/* Primary flow stroke */}
                  <path
                    d={pathD}
                    fill="none"
                    stroke={
                      edge.isActive
                        ? 'url(#edge-active-gradient)'
                        : edge.isCompleted
                        ? '#10b981'
                        : '#334155'
                    }
                    strokeWidth={edge.isActive ? 2.5 : 1.5}
                    strokeDasharray={edge.isActive ? '6 4' : 'none'}
                    className={edge.isActive ? 'animate-[dash_1s_linear_infinite]' : ''}
                  />
                  {/* Subtle terminal dot on target node */}
                  <circle
                    cx={endX}
                    cy={endY}
                    r={edge.isActive ? 4 : 3}
                    fill={edge.isActive ? '#6366f1' : edge.isCompleted ? '#10b981' : '#475569'}
                  />
                </g>
              );
            })}
          </svg>

          {/* Render Step Nodes */}
          {layout.nodes.map((node) => {
            const isSelected = selectedStepId === node.step.id;
            const exec = node.exec;
            const status = exec?.status || 'pending';

            return (
              <div
                key={node.step.id}
                onClick={() => onSelectStep(node.step.id)}
                style={{
                  left: node.x,
                  top: node.y,
                  width: node.width,
                  height: node.height,
                }}
                className={`absolute z-10 rounded-lg p-2.5 cursor-pointer transition-all duration-150 flex flex-col justify-between border ${
                  isSelected
                    ? 'ring-2 ring-indigo-500 ring-offset-2 ring-offset-slate-950 shadow-lg'
                    : 'hover:border-slate-600'
                } ${
                  status === 'running'
                    ? 'bg-slate-900 border-indigo-500/80 shadow-md shadow-indigo-500/10'
                    : status === 'waiting_approval'
                    ? 'bg-indigo-950/40 border-amber-500/80 shadow-md shadow-amber-500/10'
                    : status === 'sleeping'
                    ? 'bg-slate-900 border-cyan-500/70'
                    : status === 'completed'
                    ? 'bg-slate-900/90 border-emerald-500/40'
                    : status === 'retrying'
                    ? 'bg-amber-950/30 border-amber-500/70 animate-pulse'
                    : status === 'failed'
                    ? 'bg-rose-950/30 border-rose-500/70'
                    : status === 'skipped'
                    ? 'bg-slate-900/50 border-slate-700/60 border-dashed opacity-70'
                    : 'bg-slate-900/70 border-slate-800'
                }`}
              >
                {/* Node Header: Status indicator and Type */}
                <div className="flex items-center justify-between gap-1.5">
                  <div className="flex items-center gap-1.5 truncate">
                    {/* Status Icon */}
                    {status === 'running' && (
                      <RotateCw className="w-3.5 h-3.5 text-indigo-400 animate-spin shrink-0" />
                    )}
                    {status === 'completed' && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    )}
                    {status === 'waiting_approval' && (
                      <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0 animate-pulse" />
                    )}
                    {status === 'sleeping' && (
                      <Moon className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    )}
                    {status === 'retrying' && (
                      <RotateCw className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    )}
                    {status === 'failed' && (
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    )}
                    {status === 'pending' && (
                      <div className="w-2.5 h-2.5 rounded-full bg-slate-700 shrink-0" />
                    )}
                    {status === 'skipped' && (
                      <ArrowRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    )}

                    <span className="text-xs font-semibold text-slate-200 truncate">
                      {node.step.name}
                    </span>
                  </div>

                  {/* Step Type Tag */}
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider shrink-0">
                    {node.step.type === 'human_approval'
                      ? 'HITL'
                      : node.step.type === 'sleep'
                      ? 'TIMER'
                      : node.step.type === 'compensation'
                      ? 'SAGA'
                      : 'STEP'}
                  </span>
                </div>

                {/* Subtitle / Description */}
                <p className="text-[11px] text-slate-400 line-clamp-1 leading-snug">
                  {node.step.description}
                </p>

                {/* Node Footer: Metadata & Execution Telemetry */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-[10px] text-slate-400 font-mono">
                  {/* Left: Queue or State detail */}
                  <div className="truncate max-w-[120px]">
                    {status === 'sleeping' ? (
                      <span className="text-cyan-300">durable sleep</span>
                    ) : status === 'waiting_approval' ? (
                      <span className="text-amber-300 font-sans font-medium">review required</span>
                    ) : (
                      <span>{node.step.taskQueue || run.taskQueue}</span>
                    )}
                  </div>

                  {/* Right: Duration or Action button */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    {status === 'waiting_approval' ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenApproval(node.step.id);
                        }}
                        className="px-2 py-0.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-sans font-semibold rounded text-[10px] transition-colors"
                      >
                        Review
                      </button>
                    ) : status === 'retrying' ? (
                      <span className="text-amber-400">
                        att #{exec?.currentAttempt}/{node.step.retryPolicy?.maxAttempts || 3}
                      </span>
                    ) : status === 'failed' ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onManualRetry(node.step.id);
                        }}
                        className="px-1.5 py-0.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 rounded font-sans transition-colors"
                      >
                        Retry
                      </button>
                    ) : exec?.durationMs ? (
                      <span className="text-slate-300 tabular-nums">
                        {exec.durationMs < 1000 ? `${exec.durationMs}ms` : `${(exec.durationMs / 1000).toFixed(1)}s`}
                      </span>
                    ) : (
                      <span className="text-slate-500">{status}</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
