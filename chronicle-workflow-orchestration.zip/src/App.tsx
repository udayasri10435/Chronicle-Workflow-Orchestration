import React, { useState, useEffect } from 'react';
import { orchestrator } from './engine/orchestrator';
import { WorkflowRun } from './types/workflow';
import { PRESET_WORKFLOWS } from './engine/presets';
import { TopNav } from './components/TopNav';
import { RunListView } from './components/RunListView';
import { ApprovalsView } from './components/ApprovalsView';
import { WorkerQueuesView } from './components/WorkerQueuesView';
import { SdkCodeView } from './components/SdkCodeView';
import { TriggerWorkflowModal } from './components/TriggerWorkflowModal';
import { HumanApprovalModal } from './components/HumanApprovalModal';

export default function App() {
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [activeRunId, setActiveRunId] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<'runs' | 'approvals' | 'queues' | 'sdk'>('runs');
  const [chaosMode, setChaosMode] = useState(false);
  const [isTriggerModalOpen, setIsTriggerModalOpen] = useState(false);

  // Approval modal target
  const [approvalTarget, setApprovalTarget] = useState<{
    runId: string;
    stepId: string;
  } | null>(null);

  // Subscribe to live orchestrator updates
  useEffect(() => {
    const unsubscribe = orchestrator.subscribe((updatedRuns) => {
      setRuns([...updatedRuns]);
      if (updatedRuns.length > 0 && !activeRunId) {
        setActiveRunId(updatedRuns[0].id);
      }
    });

    const chaos = orchestrator.getChaosSettings();
    setChaosMode(chaos.enabled);

    return () => unsubscribe();
  }, []);

  // Compute pending approvals count
  const pendingApprovalsCount = runs.reduce((acc, run) => {
    const pendingInRun = Object.values(run.stepExecutions).filter(
      (e) => e.status === 'waiting_approval'
    ).length;
    return acc + pendingInRun;
  }, 0);

  const activeRun = runs.find((r) => r.id === activeRunId) || runs[0];

  // Actions
  const handleToggleChaos = () => {
    const next = !chaosMode;
    orchestrator.setChaosMode(next, 0.4);
    setChaosMode(next);
  };

  const handleResetEngine = () => {
    orchestrator.resetAll();
  };

  const handleTriggerWorkflow = (
    workflowId: string,
    payload: Record<string, unknown>,
    trigger: 'manual' | 'api' | 'webhook' | 'cron'
  ) => {
    const newRun = orchestrator.triggerWorkflow(workflowId, payload, trigger);
    setActiveRunId(newRun.id);
    setActiveView('runs');
  };

  const handleOpenApproval = (stepId: string) => {
    if (activeRun) {
      setApprovalTarget({ runId: activeRun.id, stepId });
    }
  };

  const handleResolveApproval = (
    decision: 'approved' | 'rejected',
    reason?: string,
    amendedPayload?: Record<string, unknown>
  ) => {
    if (!approvalTarget) return;
    orchestrator.resolveApproval(
      approvalTarget.runId,
      approvalTarget.stepId,
      decision,
      reason,
      amendedPayload
    );
    setApprovalTarget(null);
  };

  const handleManualRetry = (stepId: string) => {
    if (activeRun) {
      orchestrator.retryStepNow(activeRun.id, stepId);
    }
  };

  const handleSkipStep = (stepId: string) => {
    if (activeRun) {
      orchestrator.skipStep(activeRun.id, stepId);
    }
  };

  const handleTogglePause = (runId: string) => {
    orchestrator.togglePause(runId);
  };

  const handleTerminateRun = (runId: string) => {
    orchestrator.terminateRun(runId);
  };

  // Quick helper to trigger KYC approval demo
  const handleTriggerKycApprovalDemo = () => {
    const kyc = PRESET_WORKFLOWS.find((w) => w.id === 'customer-kyc-onboarding')!;
    const newRun = orchestrator.triggerWorkflow(kyc.id, {
      ...kyc.samplePayload,
      legalName: 'Apex Capital Partners LLC',
      riskAssessmentScore: 0.89, // High risk triggers human review!
    }, 'api');
    setActiveRunId(newRun.id);
    setActiveView('runs');
  };

  // Find step definition and execution for approval modal
  const approvalRun = approvalTarget ? runs.find((r) => r.id === approvalTarget.runId) : null;
  const approvalDef = approvalRun
    ? PRESET_WORKFLOWS.find((w) => w.id === approvalRun.workflowId)
    : null;
  const approvalStepDef = approvalDef && approvalTarget
    ? approvalDef.steps.find((s) => s.id === approvalTarget.stepId)
    : null;
  const approvalStepExec = approvalRun && approvalTarget
    ? approvalRun.stepExecutions[approvalTarget.stepId]
    : null;

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
      {/* Top Navigation Bar */}
      <TopNav
        activeView={activeView}
        onSelectView={(v) => setActiveView(v)}
        pendingApprovalsCount={pendingApprovalsCount}
        onOpenTriggerModal={() => setIsTriggerModalOpen(true)}
        chaosMode={chaosMode}
        onToggleChaos={handleToggleChaos}
        onResetEngine={handleResetEngine}
        activeRun={activeRun}
      />

      {/* Main Viewport Routing */}
      <main className="flex-1 w-full h-[calc(100vh-3.5rem)] flex overflow-hidden">
        {activeView === 'runs' && (
          <RunListView
            runs={runs}
            activeRunId={activeRunId}
            onSelectRun={(id) => setActiveRunId(id)}
            onOpenTriggerModal={() => setIsTriggerModalOpen(true)}
            onOpenApproval={handleOpenApproval}
            onManualRetry={handleManualRetry}
            onSkipStep={handleSkipStep}
            onTogglePause={handleTogglePause}
            onTerminateRun={handleTerminateRun}
          />
        )}

        {activeView === 'approvals' && (
          <ApprovalsView
            runs={runs}
            onOpenApproval={(runId, stepId) => setApprovalTarget({ runId, stepId })}
            onSelectRun={(runId) => {
              setActiveRunId(runId);
              setActiveView('runs');
            }}
            onTriggerApprovalDemo={handleTriggerKycApprovalDemo}
          />
        )}

        {activeView === 'queues' && <WorkerQueuesView />}

        {activeView === 'sdk' && <SdkCodeView />}
      </main>

      {/* Trigger Workflow Modal */}
      {isTriggerModalOpen && (
        <TriggerWorkflowModal
          onClose={() => setIsTriggerModalOpen(false)}
          onTrigger={handleTriggerWorkflow}
          chaosEnabled={chaosMode}
        />
      )}

      {/* Human Approval Modal */}
      {approvalTarget && approvalRun && approvalStepDef && approvalStepExec && (
        <HumanApprovalModal
          run={approvalRun}
          step={approvalStepDef}
          exec={approvalStepExec}
          onClose={() => setApprovalTarget(null)}
          onResolve={handleResolveApproval}
        />
      )}
    </div>
  );
}
